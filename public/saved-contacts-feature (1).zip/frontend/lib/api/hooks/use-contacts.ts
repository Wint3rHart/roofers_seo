'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import * as contacts from '@/lib/api/contacts';

export function useContacts(customerPublicId?: string) {
  return useQuery({
    queryKey: ['admin', 'contacts', customerPublicId ?? 'branch'],
    queryFn: () => contacts.listContacts({ customerPublicId }),
  });
}

export function useCreateContact() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: contacts.SavedContactInput) => contacts.createContact(body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'contacts'] }),
  });
}

export function useDeleteContact() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (publicId: string) => contacts.deleteContact(publicId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin', 'contacts'] }),
  });
}
