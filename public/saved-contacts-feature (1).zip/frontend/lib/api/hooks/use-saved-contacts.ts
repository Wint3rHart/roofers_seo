'use client';

// Mode-aware saved-contacts hooks — used by OrderForm, which is shared
// between the staff admin screen (branch-wide book) and the customer portal
// (their own address book). Both underlying queries/mutations are always
// called (rules-of-hooks safe); only the one matching `mode` is enabled.

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import * as contacts from '@/lib/api/contacts';
import * as portalContacts from '@/lib/api/portal-contacts';

export type ContactsMode = 'staff' | 'customer';

export function useSavedContactsList(mode: ContactsMode, customerPublicId?: string) {
  const staffQuery = useQuery({
    queryKey: ['admin', 'contacts', customerPublicId ?? 'branch'],
    queryFn: () => contacts.listContacts({ customerPublicId }),
    enabled: mode === 'staff',
  });
  const portalQuery = useQuery({
    queryKey: ['portal', 'contacts'],
    queryFn: () => portalContacts.listPortalContacts(),
    enabled: mode === 'customer',
  });
  return mode === 'staff' ? staffQuery : portalQuery;
}

export function useCreateSavedContact(mode: ContactsMode) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: contacts.SavedContactInput) =>
      mode === 'staff' ? contacts.createContact(body) : portalContacts.createPortalContact(body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin', 'contacts'] });
      qc.invalidateQueries({ queryKey: ['portal', 'contacts'] });
    },
  });
}

export function useDeleteSavedContact(mode: ContactsMode) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (publicId: string) =>
      mode === 'staff' ? contacts.deleteContact(publicId) : portalContacts.deletePortalContact(publicId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['admin', 'contacts'] });
      qc.invalidateQueries({ queryKey: ['portal', 'contacts'] });
    },
  });
}
