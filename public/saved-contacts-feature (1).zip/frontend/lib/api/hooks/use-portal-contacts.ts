'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import * as portalContacts from '@/lib/api/portal-contacts';

export function usePortalContacts() {
  return useQuery({
    queryKey: ['portal', 'contacts'],
    queryFn: () => portalContacts.listPortalContacts(),
  });
}

export function useCreatePortalContact() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: portalContacts.PortalSavedContactInput) => portalContacts.createPortalContact(body),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['portal', 'contacts'] }),
  });
}

export function useDeletePortalContact() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (publicId: string) => portalContacts.deletePortalContact(publicId),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['portal', 'contacts'] }),
  });
}
