// Staff (admin) saved-contacts API — the branch-wide address book.
// Backed by /api/contacts/* on the backend.

import { apiFetch } from './client';
import type { SavedContact, ContactKind } from './types';

export interface SavedContactInput {
  branchPublicId?: string; // required for super_admin
  kind: ContactKind;
  label: string;
  name: string;
  company?: string;
  phone?: string;
  email?: string;
  cnic?: string;
  ntn?: string;
  address?: string;
  address2?: string;
  city?: string;
  state?: string;
  country?: string;
  postcode?: string;
}

/** List the branch-wide contact book, or a specific customer's saved contacts when customerPublicId is passed. */
export function listContacts(opts: { customerPublicId?: string } = {}): Promise<SavedContact[]> {
  const qs = opts.customerPublicId ? `?customerPublicId=${opts.customerPublicId}` : '';
  return apiFetch<{ contacts: SavedContact[] }>(`/contacts${qs}`).then((r) => r.contacts);
}

export function createContact(body: SavedContactInput): Promise<{ contact: SavedContact }> {
  return apiFetch('/contacts', { method: 'POST', body });
}

export function deleteContact(publicId: string): Promise<{ ok: boolean }> {
  return apiFetch(`/contacts/${publicId}`, { method: 'DELETE' });
}
