// Customer portal saved-contacts API — each customer's own address book.
// Backed by /api/portal/contacts/* on the backend.

import { apiFetch } from './client';
import type { SavedContact, ContactKind } from './types';

export interface PortalSavedContactInput {
  kind: ContactKind;
  label: string;
  name: string;
  company?: string;
  phone?: string;
  email?: string;
  cnic?: string;
  ntn?: string;
  address?: string;
  address2?: string;
  city?: string;
  state?: string;
  country?: string;
  postcode?: string;
}

export function listPortalContacts(): Promise<SavedContact[]> {
  return apiFetch<{ contacts: SavedContact[] }>('/portal/contacts').then((r) => r.contacts);
}

export function createPortalContact(body: PortalSavedContactInput): Promise<{ contact: SavedContact }> {
  return apiFetch('/portal/contacts', { method: 'POST', body });
}

export function deletePortalContact(publicId: string): Promise<{ ok: boolean }> {
  return apiFetch(`/portal/contacts/${publicId}`, { method: 'DELETE' });
}
