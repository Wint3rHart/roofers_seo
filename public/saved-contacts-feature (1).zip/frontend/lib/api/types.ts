// ── Saved contacts (address book) ───────────────────────────────────────────
// Append this block to your existing lib/api/types.ts.

export type ContactKind = 'sender' | 'receiver' | 'both';

export interface SavedContact {
  publicId: string;
  kind: ContactKind;
  label: string;
  name: string;
  company: string | null;
  phone: string | null;
  email: string | null;
  cnic: string | null;
  ntn: string | null;
  address: string | null;
  address2: string | null;
  city: string | null;
  state: string | null;
  country: string | null;
  postcode: string | null;
  ownerCustomerId: string | null;
  createdAt: string;
  updatedAt: string;
}
