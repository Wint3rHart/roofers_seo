'use client';

import { useState } from 'react';
import { Plus, Trash2, Package, BookmarkPlus, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CountrySelect } from '@/components/forms/CountrySelect';
import { isValidInternationalPhone, PHONE_HINT } from '@/lib/validations/phone';
import {
  useSavedContactsList, useCreateSavedContact, useDeleteSavedContact, type ContactsMode,
} from '@/lib/api/hooks/use-saved-contacts';
import type { SavedContact } from '@/lib/api/types';

// ── Service type / courier option data (per PrepMax spec) ───────────────────
// No dedicated backend field exists yet for the courier/option pick — carrier
// assignment happens later in the edit-order screen. So `serviceCategory` +
// `serviceOption` are combined into the existing free-text `serviceType`
// string on submit, e.g. "Direct — Skynet". Nothing new to migrate.

export type ServiceCategory = 'Direct' | 'Via' | 'By Sea';

export interface ServiceOption {
  name: string;
  /** Delivery time shown in the confirm modal. */
  time: string;
}

export const SERVICE_CATEGORIES: ServiceCategory[] = ['Direct', 'Via', 'By Sea'];


/** Via's delivery time is uniform across every option — shown at the category level. */
export const VIA_DELIVERY_TIME = '8 to 10 Working Days';

export const DIRECT_OPTIONS: ServiceOption[] = [
  { name: 'Skynet', time: '5 to 7 Working Days' },
  { name: 'UPS', time: '4 to 6 Working Days' },
  { name: 'DHL', time: '3 to 5 Working Days' },
  { name: 'Fedex', time: '5 to 6 Working Days' },
  { name: 'DPEX', time: '5 to 7 Working Days' },
  { name: 'Aramex', time: '6 to 8 Working Days' },
];

export const VIA_OPTIONS: ServiceOption[] = [
  'Skynet Via DHL', 'Skynet Via Aramex', 'Skynet Via UPS', 'Skynet Via DPEX',
  ' UK DPD (CCP)', ' UK DPD (CC)', ' UK UPS', ' UK DHL', ' UK FedEx',
  ' Dubai DHL', ' Dubai UPS', ' Dubai Fedex', ' Dubai Aramex', ' Dubai Local',
  ' Singapore DHL', ' Singapore UPS', ' Singapore FedEx',
  'Direct JFK(USA-CCP)', 'Direct JFK(USA-CC)', 'Post Office',
].map((name) => ({ name, time: VIA_DELIVERY_TIME }));

export const BY_SEA_OPTIONS: ServiceOption[] = [
  { name: 'UK', time: '45-60 Working Days' },
  { name: 'USA', time: '50-65 Working Days' },
  { name: 'UAE', time: '30-40 Working Days' },
  { name: 'Canada', time: '50-65 Working Days' },
];

export function optionsForCategory(cat: ServiceCategory | ''): ServiceOption[] {
  if (cat === 'Direct') return DIRECT_OPTIONS;
  if (cat === 'Via') return VIA_OPTIONS;
  if (cat === 'By Sea') return BY_SEA_OPTIONS;
  return [];
}

/** Encode category + chosen option into the single `serviceType` string the backend accepts today. */
export function encodeServiceType(cat: ServiceCategory | '', option: string): string | undefined {
  if (!cat) return undefined;
  if (!option) return cat;
  return `${cat} — ${option}`;
}

/** Best-effort decode when loading an existing order back into the form. */
export function decodeServiceType(serviceType: string | null | undefined): { category: ServiceCategory | ''; option: string } {
  if (!serviceType) return { category: '', option: '' };
  const [rawCat, rawOption] = serviceType.split(' — ');
  const category = (SERVICE_CATEGORIES as string[]).includes(rawCat ?? '') ? (rawCat as ServiceCategory) : '';
  return { category, option: rawOption ?? '' };
}

// ── Types the form works with (mirror backend create/edit shape) ────────────
export interface OrderFormContact {
  name: string; company: string; phone: string; email: string; cnic: string; ntn?: string;
  address: string; address2: string; city: string; state: string; country: string; postcode: string;
}
export interface OrderFormItem { description: string; quantity: number; unitValue: string }
export interface OrderFormBox {
  parcelType: string; weightKg: string; lengthCm: string; widthCm: string; heightCm: string; items: OrderFormItem[];
}
export interface OrderFormValues {
  branchPublicId?: string;
  sender: OrderFormContact;
  receiver: OrderFormContact;
  originCountry: string;
  destinationCountry: string;
  serviceLevel: string;
  /** Direct | Via | By Sea */
  serviceCategory: ServiceCategory | '';
  /** The specific courier/option chosen within serviceCategory, e.g. "Skynet" or "UK". */
  serviceOption: string;
  contentsNature: string;
  duties: string;
  price: string;
  priceCurrency: string;
  paymentStatus: string;
  amountPaid: string;
  declaredCurrency: string;
  notes: string;
  boxes: OrderFormBox[];
}

export const emptyContact = (): OrderFormContact => ({
  name: '', company: '', phone: '', email: '', cnic: '', ntn: '',
  address: '', address2: '', city: '', state: '', country: '', postcode: '',
});
export const emptyBox = (): OrderFormBox => ({
  parcelType: 'package', weightKg: '', lengthCm: '', widthCm: '', heightCm: '',
  items: [{ description: '', quantity: 1, unitValue: '' }],
});
export const emptyOrderForm = (): OrderFormValues => ({
  sender: emptyContact(), receiver: emptyContact(),
  originCountry: '', destinationCountry: '', serviceLevel: 'Standard',
  serviceCategory: '', serviceOption: '',
  contentsNature: '', duties: '', price: '', priceCurrency: 'PKR',
  paymentStatus: 'unpaid', amountPaid: '', declaredCurrency: 'USD', notes: '',
  boxes: [emptyBox()],
});

// Map a loaded order detail into editable form values.
import type { AdminOrderDetail, AdminContact } from '@/lib/api/admin';
export function orderDetailToForm(o: AdminOrderDetail): OrderFormValues {
  const c = (src?: Partial<AdminContact>): OrderFormContact => ({
    name: src?.name ?? '', company: src?.company ?? '', phone: src?.phone ?? '', email: src?.email ?? '',
    cnic: src?.cnic ?? '', ntn: src?.ntn ?? '', address: src?.address ?? '', address2: src?.address2 ?? '',
    city: src?.city ?? '', state: src?.state ?? '', country: src?.country ?? '', postcode: src?.postcode ?? '',
  });
  const { category, option } = decodeServiceType(o.serviceType);
  return {
    sender: c(o.sender), receiver: c(o.receiver),
    originCountry: o.originCountry ?? '', destinationCountry: o.destinationCountry ?? '',
    serviceLevel: o.serviceLevel ?? 'Standard',
    serviceCategory: category, serviceOption: option,
    contentsNature: o.contentsNature ?? '', duties: o.duties ?? '',
    price: o.price != null ? String(o.price) : '', priceCurrency: o.priceCurrency ?? 'PKR',
    paymentStatus: o.paymentStatus ?? 'unpaid', amountPaid: o.amountPaid != null ? String(o.amountPaid) : '',
    declaredCurrency: o.declaredCurrency ?? 'USD', notes: o.notes ?? '',
    boxes: o.boxes.map((b) => ({
      parcelType: b.parcelType ?? 'package',
      weightKg: String(b.weightKg), lengthCm: String(b.lengthCm), widthCm: String(b.widthCm), heightCm: String(b.heightCm),
      items: b.items.length ? b.items.map((it) => ({ description: it.description, quantity: it.quantity, unitValue: it.unitValue != null ? String(it.unitValue) : '' })) : [{ description: '', quantity: 1, unitValue: '' }],
    })),
  };
}

const PARCEL_TYPES = ['package', 'document', 'pallet', 'fragile', 'oversized', 'other'];
const inputCls = 'h-10 w-full rounded-lg border border-gray-200 bg-white px-3 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30';
const selectCls = inputCls;

/** Convert form (string) values → API payload (typed). */
export function orderFormToPayload(v: OrderFormValues, opts: { includeBranch?: boolean } = {}) {
  const num = (s: string) => (s.trim() === '' ? undefined : Number(s));
  const contact = (c: OrderFormContact) => ({
    name: c.name || undefined, company: c.company || undefined, phone: c.phone || undefined,
    email: c.email || undefined, cnic: c.cnic || undefined, ntn: c.ntn || undefined,
    address: c.address || undefined, address2: c.address2 || undefined, city: c.city || undefined,
    state: c.state || undefined, country: c.country || undefined, postcode: c.postcode || undefined,
  });
  return {
    ...(opts.includeBranch && v.branchPublicId ? { branchPublicId: v.branchPublicId } : {}),
    sender: contact(v.sender), receiver: contact(v.receiver),
    originCountry: v.originCountry || undefined,
    destinationCountry: v.destinationCountry || undefined,
    serviceLevel: v.serviceLevel || undefined,
    serviceType: encodeServiceType(v.serviceCategory, v.serviceOption),
    contentsNature: (v.contentsNature || undefined) as 'documents' | 'merchandise' | undefined,
    duties: (v.duties || undefined) as 'DTP' | 'DTU' | undefined,
    price: num(v.price), priceCurrency: v.priceCurrency,
    paymentStatus: (v.paymentStatus || undefined) as 'unpaid' | 'paid' | 'partial' | undefined,
    amountPaid: num(v.amountPaid), declaredCurrency: v.declaredCurrency,
    notes: v.notes || undefined,
    boxes: v.boxes.map((b) => ({
      parcelType: b.parcelType as 'package',
      weightKg: Number(b.weightKg) || 0, lengthCm: Number(b.lengthCm) || 0,
      widthCm: Number(b.widthCm) || 0, heightCm: Number(b.heightCm) || 0,
      items: b.items.map((it) => ({
        description: it.description, quantity: Number(it.quantity) || 1,
        unitValue: it.unitValue.trim() === '' ? undefined : Number(it.unitValue),
      })),
    })),
  };
}

export function validateOrderForm(v: OrderFormValues): string | null {
  if (!v.receiver.name.trim()) return 'Receiver name is required.';
  if (!v.receiver.city.trim()) return 'Receiver city is required.';
  if (!v.receiver.country.trim()) return 'Receiver country is required.';
  if (!v.serviceCategory) return 'Select a service type.';
  if (!v.serviceOption) return 'Select a service / courier option.';
  for (const c of [v.sender, v.receiver]) {
    if (c.phone && !isValidInternationalPhone(c.phone)) return PHONE_HINT;
  }
  for (let i = 0; i < v.boxes.length; i++) {
    const b = v.boxes[i]!;
    if (b.items.length === 0) return `Box ${i + 1} needs at least one item.`;
    for (const it of b.items) if (!it.description.trim()) return `Box ${i + 1}: item description required.`;
  }
  return null;
}

// ── The form ────────────────────────────────────────────────────────────────
export function OrderForm({
  value, onChange, branches, showBranch, hidePricing, contactsMode,
}: {
  value: OrderFormValues;
  onChange: (v: OrderFormValues) => void;
  branches?: { publicId: string; name: string; city: string }[];
  showBranch?: boolean;
  /** Customer bookings don't set what the vendor charges — hide the pricing section. */
  hidePricing?: boolean;
  /**
   * Enables the "load / save saved contact" address-book feature on the
   * Sender/Receiver sections. 'staff' uses the branch-wide contact book;
   * 'customer' uses the logged-in customer's own book. Omit to hide the
   * feature entirely (e.g. for a context where it doesn't make sense).
   */
  contactsMode?: ContactsMode;
}) {
  const set = (patch: Partial<OrderFormValues>) => onChange({ ...value, ...patch });
  const setContact = (which: 'sender' | 'receiver', patch: Partial<OrderFormContact>) =>
    onChange({ ...value, [which]: { ...value[which], ...patch } });
  const setBox = (i: number, patch: Partial<OrderFormBox>) =>
    onChange({ ...value, boxes: value.boxes.map((b, j) => (j === i ? { ...b, ...patch } : b)) });

  // Delivery-time confirmation: shown once per order (i.e. once per lifetime of
  // this form instance), regardless of how many times the option is changed
  // afterward.
  const [hasConfirmedDelivery, setHasConfirmedDelivery] = useState(false);
  const [pendingOption, setPendingOption] = useState<{ category: ServiceCategory; option: ServiceOption } | null>(null);

  const optionList = optionsForCategory(value.serviceCategory);

  function handleCategoryChange(next: string) {
    const category = (next as ServiceCategory) || '';
    // Changing the category invalidates the previously chosen option.
    set({ serviceCategory: category, serviceOption: '' });
  }

  function handleOptionChange(optionName: string) {
    if (!value.serviceCategory || !optionName) {
      set({ serviceOption: '' });
      return;
    }
    const opt = optionList.find((o) => o.name === optionName);
    if (!opt) return;

    if (hasConfirmedDelivery) {
      set({ serviceOption: opt.name });
      return;
    }
    // First selection this order — hold it and show the confirm modal instead
    // of committing immediately.
    setPendingOption({ category: value.serviceCategory, option: opt });
  }

  function confirmPendingOption() {
    if (!pendingOption) return;
    set({ serviceOption: pendingOption.option.name });
    setHasConfirmedDelivery(true);
    setPendingOption(null);
  }

  function cancelPendingOption() {
    setPendingOption(null);
    // Selection reverts — serviceOption stays whatever it was (unset on first pick).
  }

  return (
    <div className="space-y-6">
      {showBranch && branches && (
        <Section title="Branch">
          <select value={value.branchPublicId ?? ''} onChange={(e) => set({ branchPublicId: e.target.value })} className={selectCls}>
            <option value="">Select a branch…</option>
            {branches.map((b) => <option key={b.publicId} value={b.publicId}>{b.name} — {b.city}</option>)}
          </select>
        </Section>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        <ContactSection
          title="Sender" partyKind="sender" c={value.sender} onChange={(p) => setContact('sender', p)}
          contactsMode={contactsMode} branchPublicId={value.branchPublicId} branchRequired={!!showBranch}
        />
        <ContactSection
          title="Receiver" partyKind="receiver" c={value.receiver} onChange={(p) => setContact('receiver', p)} required
          contactsMode={contactsMode} branchPublicId={value.branchPublicId} branchRequired={!!showBranch}
        />
      </div>

      <Section title="Shipment">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Field label="From (origin country)">
            <CountrySelect value={value.originCountry} onChange={(v) => set({ originCountry: v })} />
          </Field>
          <Field label="To (destination country)">
            <CountrySelect value={value.destinationCountry} onChange={(v) => set({ destinationCountry: v })} />
          </Field>
          <Field label="Service type">
            <select value={value.serviceCategory} onChange={(e) => handleCategoryChange(e.target.value)} className={selectCls}>
              <option value="">Select…</option>
              {SERVICE_CATEGORIES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Service / courier">
            <select
              value={value.serviceOption}
              onChange={(e) => handleOptionChange(e.target.value)}
              className={selectCls}
              disabled={!value.serviceCategory}
            >
              <option value="">{value.serviceCategory ? 'Select…' : 'Select a service type first'}</option>
              {optionList.map((o) => <option key={o.name} value={o.name}>{o.name}</option>)}
            </select>
          </Field>
          <Field label="Service level">
            <select value={value.serviceLevel} onChange={(e) => set({ serviceLevel: e.target.value })} className={selectCls}>
              {['Standard', 'Express', 'Economy', 'Freight'].map((s) => <option key={s}>{s}</option>)}
            </select>
          </Field>
          <Field label="Contents">
            <select value={value.contentsNature} onChange={(e) => set({ contentsNature: e.target.value })} className={selectCls}>
              <option value="">—</option><option value="documents">Documents</option><option value="merchandise">Merchandise</option>
            </select>
          </Field>
          <Field label="Duties">
            <select value={value.duties} onChange={(e) => set({ duties: e.target.value })} className={selectCls}>
              <option value="">—</option><option value="DTP">DTP (paid)</option><option value="DTU">DTU (unpaid)</option>
            </select>
          </Field>
        </div>
      </Section>

      {!hidePricing && (
        <Section title="Pricing">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Field label="Price (what we charge)">
              <Input type="number" step="0.01" value={value.price} onChange={(e) => set({ price: e.target.value })} />
            </Field>
            <Field label="Price currency">
              <Input value={value.priceCurrency} onChange={(e) => set({ priceCurrency: e.target.value })} />
            </Field>
            <Field label="Payment status">
              <select value={value.paymentStatus} onChange={(e) => set({ paymentStatus: e.target.value })} className={selectCls}>
                <option value="unpaid">Unpaid</option><option value="partial">Partial</option><option value="paid">Paid</option>
              </select>
            </Field>
            <Field label="Amount paid">
              <Input type="number" step="0.01" value={value.amountPaid} onChange={(e) => set({ amountPaid: e.target.value })} />
            </Field>
          </div>
          <p className="mt-2 text-xs text-gray-500">Declared customs value is summed automatically from item values below.</p>
        </Section>
      )}

      <Section title="Boxes & Items">
        <div className="mb-3 flex justify-end">
          <Button type="button" variant="outline" size="sm" className="gap-1" onClick={() => set({ boxes: [...value.boxes, emptyBox()] })}>
            <Plus className="h-4 w-4" /> Add box
          </Button>
        </div>
        <div className="space-y-5">
          {value.boxes.map((box, bi) => (
            <div key={bi} className="rounded-xl border border-gray-200 p-4">
              <div className="mb-3 flex items-center justify-between">
                <p className="flex items-center gap-2 font-medium"><Package className="h-4 w-4 text-primary" /> Box {bi + 1}</p>
                {value.boxes.length > 1 && (
                  <button type="button" onClick={() => set({ boxes: value.boxes.filter((_, j) => j !== bi) })} className="text-gray-400 hover:text-error"><Trash2 className="h-4 w-4" /></button>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
                <Field label="Type">
                  <select value={box.parcelType} onChange={(e) => setBox(bi, { parcelType: e.target.value })} className={selectCls}>
                    {PARCEL_TYPES.map((t) => <option key={t} value={t}>{t[0].toUpperCase() + t.slice(1)}</option>)}
                  </select>
                </Field>
                <Field label="Weight (kg)"><Input type="number" step="0.01" value={box.weightKg} onChange={(e) => setBox(bi, { weightKg: e.target.value })} /></Field>
                <Field label="L (cm)"><Input type="number" step="0.1" value={box.lengthCm} onChange={(e) => setBox(bi, { lengthCm: e.target.value })} /></Field>
                <Field label="W (cm)"><Input type="number" step="0.1" value={box.widthCm} onChange={(e) => setBox(bi, { widthCm: e.target.value })} /></Field>
                <Field label="H (cm)"><Input type="number" step="0.1" value={box.heightCm} onChange={(e) => setBox(bi, { heightCm: e.target.value })} /></Field>
              </div>
              <div className="mt-3">
                <div className="mb-2 flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-600">Items</p>
                  <button type="button" onClick={() => setBox(bi, { items: [...box.items, { description: '', quantity: 1, unitValue: '' }] })} className="inline-flex items-center gap-1 text-sm text-primary hover:underline">
                    <Plus className="h-3.5 w-3.5" /> Add item
                  </button>
                </div>
                <div className="space-y-2">
                  {box.items.map((it, ii) => (
                    <div key={ii} className="flex items-center gap-2">
                      <Input placeholder="Description" value={it.description} className="flex-1"
                        onChange={(e) => setBox(bi, { items: box.items.map((x, j) => (j === ii ? { ...x, description: e.target.value } : x)) })} />
                      <Input type="number" placeholder="Qty" className="w-20" value={it.quantity}
                        onChange={(e) => setBox(bi, { items: box.items.map((x, j) => (j === ii ? { ...x, quantity: Number(e.target.value) || 1 } : x)) })} />
                      <Input type="number" step="0.01" placeholder="Value ($)" className="w-28" value={it.unitValue}
                        onChange={(e) => setBox(bi, { items: box.items.map((x, j) => (j === ii ? { ...x, unitValue: e.target.value } : x)) })} />
                      {box.items.length > 1 && (
                        <button type="button" onClick={() => setBox(bi, { items: box.items.filter((_, j) => j !== ii) })} className="text-gray-400 hover:text-error"><Trash2 className="h-4 w-4" /></button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Notes">
        <textarea value={value.notes} onChange={(e) => set({ notes: e.target.value })} rows={2} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30" />
      </Section>

      {pendingOption && (
        <DeliveryTimeModal
          category={pendingOption.category}
          option={pendingOption.option}
          onConfirm={confirmPendingOption}
          onCancel={cancelPendingOption}
        />
      )}
    </div>
  );
}

function DeliveryTimeModal({
  category, option, onConfirm, onCancel,
}: {
  category: ServiceCategory;
  option: ServiceOption;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-6 shadow-xl">
        <h3 className="text-lg font-bold">Confirm delivery time</h3>
        <p className="mt-2 text-sm text-gray-600">
          <span className="font-medium">{category} — {option.name}</span> will take approximately{' '}
          <span className="font-medium">{option.time}</span> to deliver.
        </p>
        <p className="mt-2 text-xs text-gray-500">
          This is an estimate, not a confirmed date — actual delivery may be a day or two earlier or later.
          If you agree, proceed. If not, the order can&apos;t be created with this selection.
        </p>
        <div className="mt-6 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
          <Button type="button" onClick={onConfirm}>Agree &amp; Proceed</Button>
        </div>
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-gray-200 bg-white p-5 sm:p-6">
      <h2 className="mb-4 font-bold">{title}</h2>
      {children}
    </section>
  );
}
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label className="mb-1 block text-xs font-medium text-gray-600">{label}</label>{children}</div>;
}

// Fields that make up an OrderFormContact — used both to fill from a saved
// contact and to snapshot into one.
function contactFromSaved(sc: SavedContact): OrderFormContact {
  return {
    name: sc.name, company: sc.company ?? '', phone: sc.phone ?? '', email: sc.email ?? '',
    cnic: sc.cnic ?? '', ntn: sc.ntn ?? '', address: sc.address ?? '', address2: sc.address2 ?? '',
    city: sc.city ?? '', state: sc.state ?? '', country: sc.country ?? '', postcode: sc.postcode ?? '',
  };
}

function ContactSection({
  title, partyKind, c, onChange, required, contactsMode, branchPublicId, branchRequired,
}: {
  title: string;
  partyKind: 'sender' | 'receiver';
  c: OrderFormContact;
  onChange: (p: Partial<OrderFormContact>) => void;
  required?: boolean;
  contactsMode?: ContactsMode;
  branchPublicId?: string;
  /** True when the current user (super-admin) must pick a branch before a contact can be saved. */
  branchRequired?: boolean;
}) {
  const req = required ? ' *' : '';
  const contactsEnabled = !!contactsMode;

  // Only fetch the list when this feature is actually enabled.
  const { data: savedContacts, isLoading: savedLoading } = useSavedContactsList(contactsMode ?? 'customer');
  const createContact = useCreateSavedContact(contactsMode ?? 'customer');
  const deleteContact = useDeleteSavedContact(contactsMode ?? 'customer');

  const [selectedId, setSelectedId] = useState('');
  const [saveOpen, setSaveOpen] = useState(false);
  const [saveLabel, setSaveLabel] = useState('');
  const [saveError, setSaveError] = useState('');

  const relevant = (savedContacts ?? []).filter((sc) => sc.kind === 'both' || sc.kind === partyKind);

  function handleLoad(publicId: string) {
    setSelectedId(publicId);
    if (!publicId) return;
    const found = relevant.find((sc) => sc.publicId === publicId);
    if (found) onChange(contactFromSaved(found));
  }

  async function handleSave() {
    setSaveError('');
    if (branchRequired && !branchPublicId) {
      setSaveError('Select a branch above first — contacts are saved per branch.');
      return;
    }
    if (!saveLabel.trim()) { setSaveError('Give this contact a short label, e.g. "Main Office".'); return; }
    if (!c.name.trim()) { setSaveError('Fill in a name before saving.'); return; }
    try {
      await createContact.mutateAsync({
        branchPublicId,
        kind: partyKind,
        label: saveLabel.trim(),
        name: c.name, company: c.company || undefined, phone: c.phone || undefined,
        email: c.email || undefined, cnic: c.cnic || undefined, ntn: c.ntn || undefined,
        address: c.address || undefined, address2: c.address2 || undefined, city: c.city || undefined,
        state: c.state || undefined, country: c.country || undefined, postcode: c.postcode || undefined,
      });
      setSaveOpen(false);
      setSaveLabel('');
    } catch {
      setSaveError('Could not save this contact. Please try again.');
    }
  }

  return (
    <Section title={title}>
      {contactsEnabled && (
        <div className="mb-4 flex flex-wrap items-center gap-2 rounded-lg bg-gray-50 p-3">
          <label className="text-xs font-medium text-gray-500">Load saved:</label>
          <select
            value={selectedId}
            onChange={(e) => handleLoad(e.target.value)}
            className="h-9 min-w-[10rem] flex-1 rounded-lg border border-gray-200 bg-white px-2 text-sm focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
          >
            <option value="">{savedLoading ? 'Loading…' : relevant.length ? 'Select a saved contact…' : 'No saved contacts yet'}</option>
            {relevant.map((sc) => (
              <option key={sc.publicId} value={sc.publicId}>{sc.label} — {sc.name}</option>
            ))}
          </select>
          {selectedId && (
            <button
              type="button"
              title="Remove from saved contacts"
              onClick={async () => { await deleteContact.mutateAsync(selectedId); setSelectedId(''); }}
              className="text-gray-400 hover:text-error"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          )}
          <Button
            type="button" variant="outline" size="sm" className="gap-1"
            onClick={() => setSaveOpen(true)}
            disabled={branchRequired && !branchPublicId}
            title={branchRequired && !branchPublicId ? 'Select a branch above first' : undefined}
          >
            <BookmarkPlus className="h-3.5 w-3.5" /> Save this contact
          </Button>
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        <Field label={`Name${req}`}><Input value={c.name} onChange={(e) => onChange({ name: e.target.value })} /></Field>
        <Field label="Company"><Input value={c.company} onChange={(e) => onChange({ company: e.target.value })} /></Field>
        <Field label="Phone (+country code)"><Input type="tel" placeholder="+92 300 1234567" value={c.phone} onChange={(e) => onChange({ phone: e.target.value })} /></Field>
        <Field label="Email"><Input type="email" value={c.email} onChange={(e) => onChange({ email: e.target.value })} /></Field>
        <Field label="CNIC"><Input placeholder="35202-1234567-1" value={c.cnic} onChange={(e) => onChange({ cnic: e.target.value })} /></Field>
        {title === 'Sender' && <Field label="NTN"><Input value={c.ntn ?? ''} onChange={(e) => onChange({ ntn: e.target.value })} /></Field>}
        <Field label="Address line 1"><Input value={c.address} onChange={(e) => onChange({ address: e.target.value })} /></Field>
        <Field label="Address line 2"><Input value={c.address2} onChange={(e) => onChange({ address2: e.target.value })} /></Field>
        <Field label={`City${req}`}><Input value={c.city} onChange={(e) => onChange({ city: e.target.value })} /></Field>
        <Field label="State / Province"><Input value={c.state} onChange={(e) => onChange({ state: e.target.value })} /></Field>
        <Field label={`Country${req}`}><CountrySelect value={c.country} onChange={(v) => onChange({ country: v })} /></Field>
        <Field label="Zip / Postal code"><Input value={c.postcode} onChange={(e) => onChange({ postcode: e.target.value })} /></Field>
      </div>

      {saveOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setSaveOpen(false)}>
          <div className="w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-6 shadow-xl" onClick={(e) => e.stopPropagation()}>
            <div className="mb-3 flex items-center justify-between">
              <h3 className="text-lg font-bold">Save {title.toLowerCase()} contact</h3>
              <button type="button" onClick={() => setSaveOpen(false)} className="text-gray-400 hover:text-gray-600"><X className="h-5 w-5" /></button>
            </div>
            <p className="mb-3 text-sm text-gray-500">Save <strong>{c.name || 'this contact'}</strong> so you can reuse it on future orders.</p>
            <Field label="Label (e.g. Main Office, Home)">
              <Input value={saveLabel} onChange={(e) => setSaveLabel(e.target.value)} autoFocus />
            </Field>
            {saveError && <p className="mt-2 text-sm text-error">{saveError}</p>}
            <div className="mt-5 flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={() => setSaveOpen(false)}>Cancel</Button>
              <Button type="button" onClick={handleSave} disabled={createContact.isPending}>
                {createContact.isPending ? 'Saving…' : 'Save contact'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </Section>
  );
}
