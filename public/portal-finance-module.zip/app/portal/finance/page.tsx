'use client';

import { useState } from 'react';
import { Wallet, FileText, X, Eye, Receipt, AlertTriangle, Inbox } from 'lucide-react';
import {
  usePortalFinanceSummary,
  usePortalInvoices,
  usePortalInvoice,
  usePortalPayments,
} from '@/lib/api/hooks/use-portal-finance';
import { InvoiceStatusBadge } from '@/components/portal/StatusBadge';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { Invoice, InvoiceStatus } from '@/lib/api/types';

const invoiceFilters: { label: string; value: InvoiceStatus | 'all' }[] = [
  { label: 'All', value: 'all' },
  { label: 'Unpaid', value: 'unpaid' },
  { label: 'Partial', value: 'partial' },
  { label: 'Paid', value: 'paid' },
];

function formatDate(iso: string | null) {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatMoney(amount: number, currency: string) {
  return `${currency} ${amount.toLocaleString('en-PK', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function isOverdue(invoice: Invoice) {
  if (invoice.status === 'paid' || invoice.status === 'void' || !invoice.dueDate) return false;
  const balance = invoice.total - invoice.amountPaid;
  return balance > 0 && new Date(invoice.dueDate) < new Date();
}

export default function PortalFinancePage() {
  const [tab, setTab] = useState<'invoices' | 'payments'>('invoices');
  const [statusFilter, setStatusFilter] = useState<InvoiceStatus | 'all'>('all');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string | null>(null);

  const { data: summary, isLoading: summaryLoading, isError: summaryError } = usePortalFinanceSummary();
  const { data: invoices, isLoading: invoicesLoading, isError: invoicesError } = usePortalInvoices(statusFilter);
  const { data: payments, isLoading: paymentsLoading, isError: paymentsError } = usePortalPayments();

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Finance</h1>
        <p className="text-sm text-gray-500">Your invoices, balance, and payment history.</p>
      </div>

      {/* Summary cards */}
      {summaryLoading && (
        <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[1, 2, 3, 4].map((i) => <div key={i} className="h-24 animate-pulse rounded-xl bg-gray-200" />)}
        </div>
      )}

      {summaryError && (
        <p className="mb-6 rounded-lg bg-red-50 p-4 text-sm text-error">
          Couldn’t load your finance summary. Please refresh, or call +92 370-7077974.
        </p>
      )}

      {summary && (
        <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-primary/30 bg-primary/5 p-5">
            <div className="mb-2 flex items-center gap-2 text-primary-hover">
              <Wallet className="h-4 w-4" />
              <p className="text-xs font-semibold uppercase tracking-wide">Outstanding Balance</p>
            </div>
            <p className="text-2xl font-bold">{formatMoney(summary.outstandingBalance, 'PKR')}</p>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-500">Total Invoiced</p>
            <p className="text-2xl font-bold">{formatMoney(summary.totalInvoiced, 'PKR')}</p>
            <p className="mt-1 text-xs text-gray-400">{summary.invoiceCount} invoice{summary.invoiceCount === 1 ? '' : 's'}</p>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-500">Total Paid</p>
            <p className="text-2xl font-bold text-green-700">{formatMoney(summary.totalPaid, 'PKR')}</p>
          </div>

          <div className="rounded-2xl border border-gray-200 bg-white p-5">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-gray-500">Pending</p>
            <p className="text-2xl font-bold text-amber-700">{formatMoney(summary.totalPending, 'PKR')}</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="mb-4 flex gap-1 border-b border-gray-200">
        <button
          onClick={() => setTab('invoices')}
          className={cn(
            'flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-sm font-medium transition',
            tab === 'invoices' ? 'border-primary text-primary-hover' : 'border-transparent text-gray-500 hover:text-gray-700',
          )}
        >
          <FileText className="h-4 w-4" /> Invoices
        </button>
        <button
          onClick={() => setTab('payments')}
          className={cn(
            'flex items-center gap-1.5 border-b-2 px-4 py-2.5 text-sm font-medium transition',
            tab === 'payments' ? 'border-primary text-primary-hover' : 'border-transparent text-gray-500 hover:text-gray-700',
          )}
        >
          <Receipt className="h-4 w-4" /> Payment History
        </button>
      </div>

      {tab === 'invoices' && (
        <div>
          {/* Status sub-filters */}
          <div className="mb-4 flex flex-wrap gap-2">
            {invoiceFilters.map((f) => (
              <button
                key={f.value}
                onClick={() => setStatusFilter(f.value)}
                className={cn(
                  'rounded-full px-3 py-1.5 text-xs font-semibold transition',
                  statusFilter === f.value
                    ? 'bg-primary text-black'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200',
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          {invoicesLoading && (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => <div key={i} className="h-20 animate-pulse rounded-xl bg-gray-200" />)}
            </div>
          )}

          {invoicesError && (
            <p className="rounded-lg bg-red-50 p-4 text-sm text-error">
              Couldn’t load your invoices. Please refresh, or call +92 370-7077974.
            </p>
          )}

          {invoices && invoices.length === 0 && (
            <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-12 text-center">
              <FileText className="mx-auto h-10 w-10 text-gray-300" />
              <h2 className="mt-3 font-semibold">No invoices found</h2>
              <p className="mt-1 text-sm text-gray-500">
                {statusFilter === 'all' ? "You don't have any invoices yet." : 'No invoices match this filter.'}
              </p>
            </div>
          )}

          {invoices && invoices.length > 0 && (
            <div className="space-y-3">
              {invoices.map((inv) => {
                const balance = inv.total - inv.amountPaid;
                const overdue = isOverdue(inv);
                return (
                  <button
                    key={inv.publicId}
                    onClick={() => setSelectedInvoiceId(inv.publicId)}
                    className="flex w-full items-center justify-between rounded-xl border border-gray-200 bg-white p-4 text-left transition hover:border-primary/40 hover:shadow-sm"
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="truncate font-semibold">{inv.invoiceNo}</p>
                        {inv.isCreditNote && (
                          <span className="rounded-full bg-blue-50 px-2 py-0.5 text-[10px] font-semibold text-blue-700">
                            Credit Note{inv.referencedInvoiceNo ? ` · ${inv.referencedInvoiceNo}` : ''}
                          </span>
                        )}
                        {overdue && (
                          <span className="flex items-center gap-1 rounded-full bg-red-50 px-2 py-0.5 text-[10px] font-semibold text-error">
                            <AlertTriangle className="h-3 w-3" /> Overdue
                          </span>
                        )}
                      </div>
                      <p className="mt-0.5 text-sm text-gray-500">
                        Issued {formatDate(inv.issueDate)}
                        {inv.dueDate ? ` · Due ${formatDate(inv.dueDate)}` : ''}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-4">
                      <div className="hidden text-right sm:block">
                        <p className="font-semibold">{formatMoney(inv.total, inv.currency)}</p>
                        {balance > 0 && inv.status !== 'void' && (
                          <p className="text-xs text-gray-400">{formatMoney(balance, inv.currency)} due</p>
                        )}
                      </div>
                      <InvoiceStatusBadge status={inv.status} />
                      <Eye className="h-4 w-4 text-gray-400" />
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {tab === 'payments' && (
        <div>
          {paymentsLoading && (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-gray-200" />)}
            </div>
          )}

          {paymentsError && (
            <p className="rounded-lg bg-red-50 p-4 text-sm text-error">
              Couldn’t load your payment history. Please refresh, or call +92 370-7077974.
            </p>
          )}

          {payments && payments.length === 0 && (
            <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-12 text-center">
              <Inbox className="mx-auto h-10 w-10 text-gray-300" />
              <h2 className="mt-3 font-semibold">No payments yet</h2>
              <p className="mt-1 text-sm text-gray-500">Payments you make will show up here.</p>
            </div>
          )}

          {payments && payments.length > 0 && (
            <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
              <table className="w-full text-sm">
                <thead className="border-b border-gray-100 bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
                  <tr>
                    <th className="px-4 py-3 text-left font-semibold">Date</th>
                    <th className="px-4 py-3 text-left font-semibold">Invoice</th>
                    <th className="px-4 py-3 text-left font-semibold">Method</th>
                    <th className="px-4 py-3 text-left font-semibold">Reference</th>
                    <th className="px-4 py-3 text-right font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {payments.map((p) => (
                    <tr key={p.publicId} className="hover:bg-gray-50/50">
                      <td className="px-4 py-3 text-gray-600">{formatDate(p.paidOn)}</td>
                      <td className="px-4 py-3">
                        {p.invoiceNo ? (
                          <button
                            className="font-medium text-primary-hover hover:underline"
                            onClick={() => p.invoicePublicId && setSelectedInvoiceId(p.invoicePublicId)}
                          >
                            {p.invoiceNo}
                          </button>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 capitalize text-gray-600">{p.method}</td>
                      <td className="px-4 py-3 text-gray-500">{p.reference || '—'}</td>
                      <td className="px-4 py-3 text-right font-semibold text-green-700">
                        +{formatMoney(p.amount, 'PKR')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {selectedInvoiceId && (
        <InvoiceDetailsModal publicId={selectedInvoiceId} onClose={() => setSelectedInvoiceId(null)} />
      )}
    </div>
  );
}

function InvoiceDetailsModal({ publicId, onClose }: { publicId: string; onClose: () => void }) {
  const { data: invoice, isLoading, isError } = usePortalInvoice(publicId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      role="dialog"
      aria-modal="true"
      onClick={onClose}
    >
      <div
        className="relative max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl bg-white p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute right-4 top-4 text-gray-400 transition hover:text-gray-600"
          aria-label="Close"
        >
          <X className="h-5 w-5" />
        </button>

        {isLoading && (
          <div className="space-y-3 pr-8">
            <div className="h-6 w-1/2 animate-pulse rounded bg-gray-200" />
            <div className="h-24 animate-pulse rounded bg-gray-200" />
            <div className="h-32 animate-pulse rounded bg-gray-200" />
          </div>
        )}

        {isError && (
          <p className="rounded-lg bg-red-50 p-4 text-sm text-error">
            Couldn’t load this invoice. Please try again.
          </p>
        )}

        {invoice && (
          <>
            <div className="mb-1 flex items-start justify-between gap-3 pr-8">
              <div className="min-w-0">
                <h3 className="truncate text-lg font-bold">{invoice.invoiceNo}</h3>
                {invoice.isCreditNote && (
                  <p className="mt-0.5 text-xs font-semibold text-blue-700">
                    Credit Note{invoice.referencedInvoiceNo ? ` for ${invoice.referencedInvoiceNo}` : ''}
                  </p>
                )}
              </div>
              <InvoiceStatusBadge status={invoice.status} />
            </div>

            <p className="mb-5 text-xs text-gray-400">
              Issued {formatDate(invoice.issueDate)}
              {invoice.dueDate ? ` · Due ${formatDate(invoice.dueDate)}` : ''}
            </p>

            {/* Line items */}
            {invoice.items && invoice.items.length > 0 && (
              <div className="mb-4 overflow-hidden rounded-lg border border-gray-100">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 text-xs uppercase tracking-wide text-gray-500">
                    <tr>
                      <th className="px-3 py-2 text-left font-semibold">Description</th>
                      <th className="px-3 py-2 text-right font-semibold">Qty</th>
                      <th className="px-3 py-2 text-right font-semibold">Unit</th>
                      <th className="px-3 py-2 text-right font-semibold">Total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {invoice.items.map((item, idx) => (
                      <tr key={idx}>
                        <td className="px-3 py-2 text-gray-700">{item.description}</td>
                        <td className="px-3 py-2 text-right text-gray-500">{item.quantity}</td>
                        <td className="px-3 py-2 text-right text-gray-500">
                          {formatMoney(item.unitPrice, invoice.currency)}
                        </td>
                        <td className="px-3 py-2 text-right font-medium text-gray-700">
                          {formatMoney(item.lineTotal, invoice.currency)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Totals breakdown */}
            <div className="space-y-1.5 rounded-lg bg-gray-50 p-3 text-sm">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>{formatMoney(invoice.subtotal, invoice.currency)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Tax</span>
                <span>{formatMoney(invoice.tax, invoice.currency)}</span>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-1.5 font-semibold text-gray-800">
                <span>Total</span>
                <span>{formatMoney(invoice.total, invoice.currency)}</span>
              </div>
              <div className="flex justify-between text-green-700">
                <span>Paid</span>
                <span>{formatMoney(invoice.amountPaid, invoice.currency)}</span>
              </div>
              <div className="flex justify-between border-t border-gray-200 pt-1.5 font-semibold text-error">
                <span>Balance Due</span>
                <span>{formatMoney(Math.max(0, invoice.total - invoice.amountPaid), invoice.currency)}</span>
              </div>
            </div>

            {invoice.notes && (
              <div className="mt-4">
                <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-gray-500">Notes</p>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-gray-700">{invoice.notes}</p>
              </div>
            )}

            <div className="mt-6 flex justify-end">
              <Button variant="outline" onClick={onClose}>
                Close
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
