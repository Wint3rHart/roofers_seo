'use client';

import { useQuery } from '@tanstack/react-query';
import {
  getPortalFinanceSummary,
  listPortalInvoices,
  getPortalInvoice,
  listPortalPayments,
} from '@/lib/api/portal-finance';
import type { InvoiceStatus } from '@/lib/api/types';

export function usePortalFinanceSummary() {
  return useQuery({
    queryKey: ['portal', 'finance', 'summary'],
    queryFn: getPortalFinanceSummary,
  });
}

export function usePortalInvoices(status: InvoiceStatus | 'all' = 'all') {
  return useQuery({
    queryKey: ['portal', 'finance', 'invoices', status],
    queryFn: () => listPortalInvoices({ status }),
  });
}

export function usePortalInvoice(publicId: string | null) {
  return useQuery({
    queryKey: ['portal', 'finance', 'invoice', publicId],
    queryFn: () => getPortalInvoice(publicId!),
    enabled: !!publicId,
  });
}

export function usePortalPayments() {
  return useQuery({
    queryKey: ['portal', 'finance', 'payments'],
    queryFn: listPortalPayments,
  });
}
