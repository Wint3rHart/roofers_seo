// Customer portal finance API functions — thin wrappers over apiFetch,
// mirroring the shape of lib/api/portal.ts (listPortalOrders, etc).
// Backed by GET /api/portal/finance/* on the backend.

import { apiFetch } from '@/lib/api/client';
import type { Invoice, InvoiceStatus, Payment } from '@/lib/api/types';

// Not in lib/api/types.ts yet — this is the portal-only summary shape
// returned by GET /api/portal/finance/summary (distinct from the staff-side
// FinanceDashboard type). Add it to types.ts alongside the other finance
// types if you'd rather keep all finance types in one place.
export interface FinanceSummary {
  outstandingBalance: number;
  totalInvoiced: number;
  totalPaid: number;
  totalPending: number;
  invoiceCount: number;
}

export function getPortalFinanceSummary() {
  return apiFetch<{ summary: FinanceSummary }>('/portal/finance/summary').then((r) => r.summary);
}

export function listPortalInvoices(opts: { status?: InvoiceStatus | 'all' } = {}) {
  const qs = opts.status && opts.status !== 'all' ? `?status=${opts.status}` : '';
  return apiFetch<{ invoices: Invoice[] }>(`/portal/finance/invoices${qs}`).then((r) => r.invoices);
}

export function getPortalInvoice(publicId: string) {
  return apiFetch<{ invoice: Invoice }>(`/portal/finance/invoices/${publicId}`).then((r) => r.invoice);
}

export function listPortalPayments() {
  return apiFetch<{ payments: Payment[] }>('/portal/finance/payments').then((r) => r.payments);
}
