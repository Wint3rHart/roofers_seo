import { cn } from '@/lib/utils';

// Shipment (tracking) status → label + color.
const shipmentStatus: Record<string, { label: string; cls: string }> = {
  info_received: { label: 'Info Received', cls: 'bg-gray-100 text-gray-700' },
  in_transit: { label: 'In Transit', cls: 'bg-primary/15 text-primary-hover' },
  out_for_delivery: { label: 'Out for Delivery', cls: 'bg-orange-100 text-orange-700' },
  delivered: { label: 'Delivered', cls: 'bg-green-100 text-green-700' },
  exception: { label: 'Exception', cls: 'bg-red-100 text-red-700' },
  unknown: { label: 'Pending', cls: 'bg-gray-100 text-gray-600' },
};

// Order (lifecycle) status → label + color.
const orderStatus: Record<string, { label: string; cls: string }> = {
  pending_approval: { label: 'Pending Approval', cls: 'bg-amber-100 text-amber-700' },
  awaiting_carrier: { label: 'Awaiting Carrier', cls: 'bg-blue-100 text-blue-700' },
  active: { label: 'Active', cls: 'bg-green-100 text-green-700' },
  delivered: { label: 'Delivered', cls: 'bg-green-100 text-green-700' },
  cancelled: { label: 'Cancelled', cls: 'bg-gray-200 text-gray-600' },
};

export function ShipmentStatusBadge({ status }: { status: string | null }) {
  const s = shipmentStatus[status ?? 'unknown'] ?? shipmentStatus.unknown;
  return <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold', s.cls)}>{s.label}</span>;
}

export function OrderStatusBadge({ status }: { status: string }) {
  const s = orderStatus[status] ?? { label: status, cls: 'bg-gray-100 text-gray-600' };
  return <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold', s.cls)}>{s.label}</span>;
}

// Complaint status → label + color.
const complaintStatus: Record<string, { label: string; cls: string }> = {
  open: { label: 'Open', cls: 'bg-amber-100 text-amber-700' },
  in_review: { label: 'In Review', cls: 'bg-blue-100 text-blue-700' },
  resolved: { label: 'Resolved', cls: 'bg-green-100 text-green-700' },
  closed: { label: 'Closed', cls: 'bg-gray-200 text-gray-600' },
};

export function ComplaintStatusBadge({ status }: { status: string }) {
  const s = complaintStatus[status] ?? { label: status, cls: 'bg-gray-100 text-gray-600' };
  return <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold', s.cls)}>{s.label}</span>;
}

// Quote status → label + color.
const quoteStatus: Record<string, { label: string; cls: string }> = {
  new: { label: 'New', cls: 'bg-amber-100 text-amber-700' },
  quoted: { label: 'Quoted', cls: 'bg-blue-100 text-blue-700' },
  accepted: { label: 'Accepted', cls: 'bg-green-100 text-green-700' },
  declined: { label: 'Declined', cls: 'bg-red-100 text-red-700' },
  closed: { label: 'Closed', cls: 'bg-gray-200 text-gray-600' },
};

export function QuoteStatusBadge({ status }: { status: string }) {
  const s = quoteStatus[status] ?? { label: status, cls: 'bg-gray-100 text-gray-600' };
  return <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold', s.cls)}>{s.label}</span>;
}

// Invoice status → label + color. (new — for the customer finance portal)
const invoiceStatus: Record<string, { label: string; cls: string }> = {
  draft: { label: 'Draft', cls: 'bg-gray-100 text-gray-600' },
  unpaid: { label: 'Unpaid', cls: 'bg-red-100 text-red-700' },
  partial: { label: 'Partially Paid', cls: 'bg-amber-100 text-amber-700' },
  paid: { label: 'Paid', cls: 'bg-green-100 text-green-700' },
  void: { label: 'Void', cls: 'bg-gray-200 text-gray-500 line-through' },
};

export function InvoiceStatusBadge({ status }: { status: string }) {
  const s = invoiceStatus[status] ?? { label: status, cls: 'bg-gray-100 text-gray-600' };
  return <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold', s.cls)}>{s.label}</span>;
}
