// Account management routes.
//   - Super-admin: create branches, branch-manager accounts, and customers.
//   - Branch manager: create customers in their own branch.
//
// Branch isolation is enforced by RLS via req.db (the manager's context can
// only INSERT rows for their own branch — the WITH CHECK policy blocks others,
// proven in the isolation tests). Permission checks gate who can call these.
import { recomputeTotals } from "../manifest/queries.js"
import { Router } from "express";
import { z } from "zod";
import { asyncHandler } from "../../lib/http.js";
import { hashPassword } from "../../lib/password.js";
import { publicId } from "../../lib/ids.js";
import {
  requireStaff,
  requirePermission,
  requireSuperAdmin,
} from "../../middleware/auth.js";
import { isStaff } from "../auth/types.js";
import { withoutContext, withSuperAdminAllBranches } from "../../db/pool.js";

export const accountsRouter: Router = Router();

// ── Create a branch (super-admin only) ──────────────────────────────────────
const branchInput = z.object({
  name: z.string().min(1),
  city: z.string().min(1),
});
accountsRouter.post(
  "/branches",
  requireStaff,
  requireSuperAdmin,
  asyncHandler(async (req, res) => {
    const parsed = branchInput.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "name and city are required" });
    const row = await withSuperAdminAllBranches(async (sql) => {
      const { rows } = await sql.query(
        `INSERT INTO branches (public_id, name, city) VALUES ($1,$2,$3)
         RETURNING id, public_id, name, city, is_active`,
        [publicId(), parsed.data.name, parsed.data.city],
      );
      const branch = rows[0];
      // Every branch needs its own house vendor ("Prepmax Logistics",
      // is_house_vendor = true) — migration 0027 only seeded this for
      // branches that existed at migration time, so any branch created
      // afterward through this route must get one here or customer-portal
      // manifests for that branch will 500 on getHouseVendorId().
      await sql.query(
        `INSERT INTO vendors (public_id, branch_id, name, vendor_type, is_house_vendor, is_protected)
         VALUES ($1,$2,'Prepmax Logistics','other',true,true)`,
        [publicId(), branch.id],
      );
      return branch;
    });
    // camelCase to match the list endpoint + frontend contract.
    return res.status(201).json({
      branch: { publicId: row.public_id, name: row.name, city: row.city, isActive: row.is_active },
    });
  }),
);

// ── Branch detail (stats + recent orders + staff + customers) ───────────────
// Gated by branches.view. A branch_manager holding that permission can only
// see their OWN branch's detail — the permission grants "can view branches",
// not "can view every branch"; withSuperAdminAllBranches is only used here to
// run the aggregate query, the branch-id check below is what enforces scope.
accountsRouter.get(
  "/branches/:publicId",
  requireStaff,
  requirePermission("branches.view"),
  asyncHandler(async (req, res) => {
    const staff = req.auth!;
    if (!isStaff(staff)) return res.status(403).json({ error: "Staff only" });
    const pid = String(req.params.publicId ?? "");
    const data = await withSuperAdminAllBranches(async (sql) => {
      const b = await sql.query(
        `SELECT id, public_id, name, city, is_active, volumetric_divisor, created_at
           FROM branches WHERE public_id = $1`,
        [pid],
      );
      if (!b.rows[0]) return null;
      const branch = b.rows[0];
      if (staff.role !== "super_admin" && branch.id !== staff.branchId) return null;
      const bid = branch.id;

      const stats = await sql.query(
        `SELECT
           (SELECT COUNT(*) FROM orders WHERE branch_id = $1)                                   AS order_count,
           (SELECT COUNT(*) FROM orders WHERE branch_id = $1 AND order_status = 'delivered')     AS delivered_count,
           (SELECT COUNT(*) FROM orders WHERE branch_id = $1
              AND order_status NOT IN ('delivered','cancelled'))                                 AS active_count,
           (SELECT COALESCE(SUM(price),0) FROM orders WHERE branch_id = $1)                      AS revenue,
           (SELECT COUNT(*) FROM customers WHERE branch_id = $1)                                 AS customer_count,
           (SELECT COUNT(*) FROM users WHERE branch_id = $1)                                     AS staff_count`,
        [bid],
      );

      const recentOrders = await sql.query(
        `SELECT public_id, tracking_code, order_status, receiver_city, receiver_country, price, created_at
           FROM orders WHERE branch_id = $1 ORDER BY created_at DESC LIMIT 10`,
        [bid],
      );
      const branchStaff = await sql.query(
        `SELECT public_id, full_name, email, role, is_active
           FROM users WHERE branch_id = $1 ORDER BY full_name`,
        [bid],
      );
      const customers = await sql.query(
        `SELECT public_id, full_name, email, is_active
           FROM customers WHERE branch_id = $1 ORDER BY created_at DESC LIMIT 25`,
        [bid],
      );
      return { branch, stats: stats.rows[0], recentOrders: recentOrders.rows, staff: branchStaff.rows, customers: customers.rows };
    });
    if (!data) return res.status(404).json({ error: "Branch not found" });
    const s = data.stats;
    return res.json({
      branch: {
        publicId: data.branch.public_id, name: data.branch.name, city: data.branch.city,
        isActive: data.branch.is_active, volumetricDivisor: data.branch.volumetric_divisor,
        createdAt: data.branch.created_at,
      },
      stats: {
        orders: Number(s.order_count), delivered: Number(s.delivered_count), active: Number(s.active_count),
        revenue: Number(s.revenue), customers: Number(s.customer_count), staff: Number(s.staff_count),
      },
      recentOrders: data.recentOrders.map((o) => ({
        publicId: o.public_id, trackingCode: o.tracking_code, orderStatus: o.order_status,
        receiverCity: o.receiver_city, receiverCountry: o.receiver_country,
        price: o.price != null ? Number(o.price) : null, createdAt: o.created_at,
      })),
      staff: data.staff.map((u) => ({
        publicId: u.public_id, fullName: u.full_name, email: u.email, role: u.role, isActive: u.is_active,
      })),
      customers: data.customers.map((c) => ({
        publicId: c.public_id, fullName: c.full_name, email: c.email, isActive: c.is_active,
      })),
    });
  }),
);

// ── Edit branch settings ─────────────────────────────────────────────────────
const branchEdit = z.object({
  name: z.string().min(1).optional(),
  city: z.string().min(1).optional(),
  isActive: z.boolean().optional(),
  volumetricDivisor: z.number().int().positive().optional(),
});
accountsRouter.patch(
  "/branches/:publicId",
  requireStaff,
  requirePermission("branches.edit"),
  asyncHandler(async (req, res) => {
    const staff = req.auth!;
    if (!isStaff(staff)) return res.status(403).json({ error: "Staff only" });
    const parsed = branchEdit.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid branch edit" });
    const pid = String(req.params.publicId ?? "");
    const updated = await withSuperAdminAllBranches(async (sql) => {
      // Same scoping as the detail route: a manager can only edit their own branch.
      if (staff.role !== "super_admin") {
        const b = await sql.query<{ id: string }>("SELECT id FROM branches WHERE public_id = $1", [pid]);
        if (!b.rows[0] || b.rows[0].id !== staff.branchId) return 0;
      }
      const set: string[] = []; const vals: unknown[] = [];
      const push = (col: string, v: unknown) => { vals.push(v); set.push(`${col} = $${vals.length}`); };
      if (parsed.data.name !== undefined) push("name", parsed.data.name);
      if (parsed.data.city !== undefined) push("city", parsed.data.city);
      if (parsed.data.isActive !== undefined) push("is_active", parsed.data.isActive);
      if (parsed.data.volumetricDivisor !== undefined) push("volumetric_divisor", parsed.data.volumetricDivisor);
      if (set.length === 0) return 1;
      vals.push(pid);
      const r = await sql.query(`UPDATE branches SET ${set.join(", ")} WHERE public_id = $${vals.length}`, vals);
      return r.rowCount ?? 0;
    });
    if (updated === 0) return res.status(404).json({ error: "Branch not found" });
    return res.json({ ok: true });
  }),
);

// ── Delete a branch (full cascade) ──────────────────────────────────────────
// branches are ON DELETE RESTRICT from orders/customers/users, so we tear
// those down in FK order first. Orders cascade to boxes/items/legs/tracking.
accountsRouter.delete(
  "/branches/:publicId",
  requireStaff,
  requireSuperAdmin,
  asyncHandler(async (req, res) => {
    const staff = req.auth!;
    if (!isStaff(staff)) return res.status(403).json({ error: "Staff only" });
    const pid = String(req.params.publicId ?? "");
    const result = await withSuperAdminAllBranches(async (sql) => {
      const b = await sql.query<{ id: string }>("SELECT id FROM branches WHERE public_id = $1", [pid]);
      if (!b.rows[0]) return null;
      // Route is super-admin-only (see requireSuperAdmin above), so the
      // old own-branch scoping check is no longer reachable — a super
      // admin can delete any branch, which is the point of this route.
      const bid = b.rows[0].id;
      // manifest_shipments/de_manifest_shipments cascade automatically once
      // their parent manifests/de_manifests rows are deleted — delete those
      // parents first, before touching orders (which manifest_shipments.order_id
      // restricts against).
      await sql.query("DELETE FROM manifests WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM de_manifests WHERE branch_id = $1", [bid]);

      // vendor_bill_items/invoice_items cascade from their parents.
      await sql.query("DELETE FROM payments WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM vendor_bills WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM invoices WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM expenses WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM vendors WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM bank_accounts WHERE branch_id = $1", [bid]);

   await sql.query("DELETE FROM saved_contacts WHERE branch_id = $1", [bid]);
      // quote_messages/complaint_messages CASCADE from quotes/complaints —
      // deleting those two tables below cleans the messages up automatically,
      // no separate DELETE needed (there is no single "conversations" table).
      await sql.query("DELETE FROM complaints WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM quotes WHERE branch_id = $1", [bid]);

      const o = await sql.query("DELETE FROM orders WHERE branch_id = $1", [bid]);
      const c = await sql.query("DELETE FROM customers WHERE branch_id = $1", [bid]);
      const u = await sql.query("DELETE FROM users WHERE branch_id = $1", [bid]);
      await sql.query("DELETE FROM branches WHERE id = $1", [bid]);
      return { orders: o.rowCount ?? 0, customers: c.rowCount ?? 0, staff: u.rowCount ?? 0 };
    });
    if (!result) return res.status(404).json({ error: "Branch not found" });
    return res.json({ ok: true, deleted: result });
  }),
);

// ── Create a staff account (accounts.add) ───────────────────────────────────
// Historically this route only ever created branch_manager-type accounts and
// was locked to requireSuperAdmin. It's now the general "create staff"
// endpoint — gated by the accounts.add permission like every other staff
// mutation, matching accounts.edit on PATCH /staff/:publicId in
// staff/routes.ts. A few things that change with that:
//
// - Branch scoping: a non-super-admin is forced into their OWN branch
//   (branchPublicId, if sent, must match) — same posture as POST /customers.
//   Only a super-admin may target an arbitrary branch.
// - Granting the RBAC "Branch Manager" role specifically stays
//   super-admin-only, even for someone holding accounts.add — same rule as
//   staff/routes.ts POST /:publicId/roles, checked via actor.roleNames so
//   it isn't fooled by users.role.
// - The 1:1-per-branch check below is scoped to that SAME condition — only
//   when the role actually being granted is the global "Branch Manager"
//   role. It must NOT key off users.role='branch_manager', because every
//   non-super-admin staff account has that value regardless of which RBAC
//   role they hold; checking it unconditionally would block creating a
//   second staff member of any kind once a branch has its first one.
const managerInput = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(1),
  branchPublicId: z.string().min(1),
  // roles.id (raw uuid) — same id the permissions page already uses.
  // Optional: omitted falls back to the global "Branch Manager" role.
  roleId: z.string().uuid().optional(),
});
accountsRouter.post(
  "/managers",
  requireStaff,
  requirePermission("accounts.add"),
  asyncHandler(async (req, res) => {
    const actor = req.auth!;
    if (!isStaff(actor)) return res.status(403).json({ error: "Staff only" });
    const parsed = managerInput.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "email, password (min 8), fullName, branchPublicId required" });
    }
    const hash = await hashPassword(parsed.data.password);
    try {
      const row = await withSuperAdminAllBranches(async (sql) => {
        const b = await sql.query<{ id: string }>(
          "SELECT id FROM branches WHERE public_id = $1",
          [parsed.data.branchPublicId],
        );
        if (!b.rows[0]) throw new HttpError(404, "Branch not found");

        // Branch scoping: non-super-admins are forced to their own branch.
        if (actor.role !== "super_admin" && b.rows[0].id !== actor.branchId) {
          throw new HttpError(403, "You can only create staff in your own branch");
        }

        let roleId: string;
        let roleName: string;
        let roleIsGlobal: boolean;
        if (parsed.data.roleId) {
          const r = await sql.query<{ id: string; name: string; branch_id: string | null }>(
            `SELECT id, name, branch_id FROM roles WHERE id = $1 AND (branch_id IS NULL OR branch_id = $2)`,
            [parsed.data.roleId, b.rows[0].id],
          );
          if (!r.rows[0]) throw new HttpError(404, "Role not found");
          roleId = r.rows[0].id;
          roleName = r.rows[0].name;
          roleIsGlobal = r.rows[0].branch_id === null;
        } else {
          const r = await sql.query<{ id: string; name: string }>(
            `SELECT id, name FROM roles WHERE branch_id IS NULL AND name = 'Branch Manager'`,
          );
          if (!r.rows[0]) throw new HttpError(500, "Default Branch Manager role missing");
          roleId = r.rows[0].id;
          roleName = r.rows[0].name;
          roleIsGlobal = true;
        }
     const grantingBranchManagerRole = roleIsGlobal && roleName === "Branch Manager";

// Only a real DB-level super_admin can hand out the global Branch
// Manager role — accounts.add alone isn't enough, same as
// staff/routes.ts. Checked against actor.role (the immutable DB column),
// not an RBAC role name, since anyone could create/hold a custom RBAC
// role also named "Super Admin".
if (grantingBranchManagerRole && actor.role !== "super_admin") {
  throw new HttpError(403, "Only a super-admin can assign the Branch Manager role");
}

        // 1:1 enforcement, scoped to the Branch Manager role specifically —
        // not to users.role, which every staff account shares.
        if (grantingBranchManagerRole) {
          const existing = await sql.query<{ id: string }>(
            `SELECT ur.user_id AS id FROM user_roles ur
               JOIN users tu ON tu.id = ur.user_id
              WHERE ur.role_id = $1 AND tu.branch_id = $2`,
            [roleId, b.rows[0].id],
          );
          if (existing.rows[0]) {
            throw new HttpError(409, "This branch already has a Branch Manager assigned");
          }
        }

        const { rows } = await sql.query<{ id: string; public_id: string; email: string; full_name: string; branch_id: string }>(
          `INSERT INTO users (public_id, branch_id, role, email, password_hash, full_name)
           VALUES ($1,$2,'branch_manager',$3,$4,$5)
           RETURNING id, public_id, email, full_name, branch_id`,
          [publicId(), b.rows[0].id, parsed.data.email, hash, parsed.data.fullName],
        );
        const newUser = rows[0]!;
        await sql.query(
          `INSERT INTO user_roles (user_id, role_id) VALUES ($1,$2) ON CONFLICT DO NOTHING`,
          [newUser.id, roleId],
        );
        return { publicId: newUser.public_id, email: newUser.email, fullName: newUser.full_name };
      });
      return res.status(201).json({ manager: row });
    } catch (err) {
      return handleError(err, res, "A user with that email already exists");
    }
  }),
);

// ── Create a customer account (super-admin OR branch manager) ───────────────
const customerInput = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().min(1),
  phone: z.string().optional(),
  // Business fields (all optional per client): company, NTN (tax no.), address.
  companyName: z.string().optional(),
  ntn: z.string().optional(),
  address: z.string().optional(),
  // super-admin may target a branch; managers always use their own
  branchPublicId: z.string().optional(),
});
accountsRouter.post(
  "/customers",
  requireStaff,
  requirePermission("customers.create"),
  asyncHandler(async (req, res) => {
    const parsed = customerInput.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: "email, password (min 8), fullName required" });
    }
    const staff = req.auth!;
    if (!isStaff(staff)) return res.status(403).json({ error: "Staff only" });
    const hash = await hashPassword(parsed.data.password);

    try {
      const row = await req.db!(async (sql) => {
        // Resolve the target branch:
        //   - branch_manager: forced to their own branch
        //   - super_admin: must specify branchPublicId
        let branchId: string;
        if (staff.role === "branch_manager") {
          branchId = staff.branchId!;
        } else {
          if (!parsed.data.branchPublicId) throw new HttpError(400, "branchPublicId required for super-admin");
          const b = await sql.query<{ id: string }>(
            "SELECT id FROM branches WHERE public_id = $1",
            [parsed.data.branchPublicId],
          );
          if (!b.rows[0]) throw new HttpError(404, "Branch not found");
          branchId = b.rows[0].id;
        }
        const { rows } = await sql.query(
          `INSERT INTO customers (public_id, branch_id, full_name, email, phone, password_hash,
                                  company_name, ntn, address)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
           RETURNING public_id, full_name, email, phone, company_name, ntn, address`,
          [publicId(), branchId, parsed.data.fullName, parsed.data.email, parsed.data.phone ?? null, hash,
           parsed.data.companyName ?? null, parsed.data.ntn ?? null, parsed.data.address ?? null],
        );
        const c = rows[0];
        return {
          publicId: c.public_id, fullName: c.full_name, email: c.email, phone: c.phone,
          companyName: c.company_name, ntn: c.ntn, address: c.address,
        };
      });
      return res.status(201).json({ customer: row });
    } catch (err) {
      return handleError(err, res, "A customer with that email already exists in this branch");
    }
  }),
);

// ── List branches (super-admin sees all; managers see their own) ────────────
accountsRouter.get(
  "/branches",
  requireStaff,
  asyncHandler(async (req, res) => {
    const staff = req.auth!;
    if (!isStaff(staff)) return res.status(403).json({ error: "Staff only" });
    const search = typeof req.query.q === "string" ? req.query.q.trim() : "";
    const rows = await withSuperAdminAllBranches(async (sql) => {
      const conds: string[] = [];
      const params: unknown[] = [];
      if (staff.role !== "super_admin") {
        params.push(staff.branchId);
        conds.push(`id = $${params.length}`);
      }
      if (search) {
        params.push(`%${search}%`);
        conds.push(`(name ILIKE $${params.length} OR city ILIKE $${params.length})`);
      }
      const where = conds.length ? `WHERE ${conds.join(" AND ")}` : "";
      const r = await sql.query(
        `SELECT public_id, name, city, is_active, volumetric_divisor, created_at
           FROM branches ${where} ORDER BY name`,
        params,
      );
      return r.rows;
    });
    return res.json({
      branches: rows.map((b) => ({
        publicId: b.public_id, name: b.name, city: b.city, isActive: b.is_active,
        volumetricDivisor: b.volumetric_divisor, createdAt: b.created_at,
      })),
    });
  }),
);

// ── List customers (branch-scoped via req.db / RLS) ─────────────────────────
accountsRouter.get(
  "/customers",
  requireStaff,
  requirePermission("customers.view"),
  asyncHandler(async (req, res) => {
    const search = typeof req.query.q === "string" ? req.query.q.trim() : "";
    const branchPublicId = typeof req.query.branchPublicId === "string" ? req.query.branchPublicId : "";
    const rows = await req.db!(async (sql) => {
      const conds: string[] = [];
      const params: unknown[] = [];
      if (search) {
        params.push(`%${search}%`);
        conds.push(`(full_name ILIKE $${params.length} OR email ILIKE $${params.length} OR COALESCE(company_name,'') ILIKE $${params.length})`);
      }
      if (branchPublicId) {
        params.push(branchPublicId);
        conds.push(`branch_id = (SELECT id FROM branches WHERE public_id = $${params.length})`);
      }
      const where = conds.length ? `WHERE ${conds.join(" AND ")}` : "";
      const r = await sql.query(
        `SELECT public_id, full_name, email, phone, company_name, ntn, address, is_active, created_at
           FROM customers ${where} ORDER BY created_at DESC LIMIT 200`,
        params,
      );
      return r.rows;
    });
    return res.json({
      customers: rows.map((c) => ({
        publicId: c.public_id, fullName: c.full_name, email: c.email, phone: c.phone,
        companyName: c.company_name, ntn: c.ntn, address: c.address, isActive: c.is_active, createdAt: c.created_at,
      })),
    });
  }),
);

// ── Customer detail (profile + their orders) ────────────────────────────────
accountsRouter.get(
  "/customers/:publicId",
  requireStaff,
  requirePermission("customers.view"),
  asyncHandler(async (req, res) => {
    const pid = String(req.params.publicId ?? "");
    const data = await req.db!(async (sql) => {
      const c = await sql.query(
        `SELECT id, public_id, full_name, email, phone, company_name, ntn, address, is_active, created_at
           FROM customers WHERE public_id = $1`,
        [pid],
      );
      if (!c.rows[0]) return null;
      const cust = c.rows[0];
      const orders = await sql.query(
        `SELECT public_id, tracking_code, order_status, current_status, receiver_city, receiver_country, price, created_at
           FROM orders WHERE customer_id = $1 ORDER BY created_at DESC LIMIT 100`,
        [cust.id],
      );
      return { cust, orders: orders.rows };
    });
    if (!data) return res.status(404).json({ error: "Customer not found" });
    const c = data.cust;
    return res.json({
      customer: {
        publicId: c.public_id, fullName: c.full_name, email: c.email, phone: c.phone,
        companyName: c.company_name, ntn: c.ntn, address: c.address, isActive: c.is_active, createdAt: c.created_at,
      },
      orders: data.orders.map((o) => ({
        publicId: o.public_id, trackingCode: o.tracking_code, orderStatus: o.order_status,
        currentStatus: o.current_status, receiverCity: o.receiver_city, receiverCountry: o.receiver_country,
        price: o.price != null ? Number(o.price) : null, createdAt: o.created_at,
      })),
    });
  }),
);

// ── Edit a customer ──────────────────────────────────────────────────────────
const customerEdit = z.object({
  fullName: z.string().min(1).optional(),
  phone: z.string().optional(),
  companyName: z.string().optional(),
  ntn: z.string().optional(),
  address: z.string().optional(),
  isActive: z.boolean().optional(),
});
accountsRouter.patch(
  "/customers/:publicId",
  requireStaff,
  requirePermission("customers.edit"),
  asyncHandler(async (req, res) => {
    const parsed = customerEdit.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid customer edit" });
    const pid = String(req.params.publicId ?? "");
    const d = parsed.data;
    const set: string[] = []; const vals: unknown[] = [];
    const push = (col: string, v: unknown) => { vals.push(v); set.push(`${col} = $${vals.length}`); };
    if (d.fullName !== undefined) push("full_name", d.fullName);
    if (d.phone !== undefined) push("phone", d.phone || null);
    if (d.companyName !== undefined) push("company_name", d.companyName || null);
    if (d.ntn !== undefined) push("ntn", d.ntn || null);
    if (d.address !== undefined) push("address", d.address || null);
    if (d.isActive !== undefined) push("is_active", d.isActive);
    if (set.length === 0) return res.json({ ok: true });
    const updated = await req.db!(async (sql) => {
      vals.push(pid);
      const r = await sql.query(`UPDATE customers SET ${set.join(", ")} WHERE public_id = $${vals.length}`, vals);
      return r.rowCount ?? 0;
    });
    if (updated === 0) return res.status(404).json({ error: "Customer not found" });
    return res.json({ ok: true });
  }),
);

// ── Delete a customer (cascade: their orders too, per client decision) ──────
accountsRouter.delete(
  "/customers/:publicId",
  requireStaff,
  requirePermission("customers.delete"),
  asyncHandler(async (req, res) => {
    const pid = String(req.params.publicId ?? "");
    try {
      const result = await req.db!(async (sql) => {
        const c = await sql.query<{ id: string }>("SELECT id FROM customers WHERE public_id = $1", [pid]);
        if (!c.rows[0]) return { found: false, orders: 0 };
        const custId = c.rows[0].id;

        const { rows: invCheck } = await sql.query<{ count: string }>(
          "SELECT COUNT(*)::text AS count FROM invoices WHERE customer_id = $1",
          [custId],
        );
        if (Number(invCheck[0]!.count) > 0) {
          throw new HttpError(409, "This customer has invoices on file and cannot be permanently deleted.");
        }

        // Unlink any of this customer's orders from manifests before deleting
        // them, same as the standalone order delete path.
        const { rows: onManifests } = await sql.query<{ manifest_id: string; order_id: string }>(
          `SELECT ms.manifest_id, ms.order_id FROM manifest_shipments ms
             JOIN orders o ON o.id = ms.order_id
            WHERE o.customer_id = $1`,
          [custId],
        );
        if (onManifests.length > 0) {
          await sql.query(
            `DELETE FROM manifest_shipments WHERE order_id IN (
               SELECT id FROM orders WHERE customer_id = $1
             )`,
            [custId],
          );
          const uniqueManifests = [...new Set(onManifests.map((r) => r.manifest_id))];
          for (const manifestId of uniqueManifests) {
            await recomputeTotals(sql, manifestId);
          }
        }

        const del = await sql.query("DELETE FROM orders WHERE customer_id = $1", [custId]);
        await sql.query("DELETE FROM customers WHERE id = $1", [custId]);
        return { found: true, orders: del.rowCount ?? 0 };
      });
      if (!result.found) return res.status(404).json({ error: "Customer not found" });
      return res.json({ ok: true, deletedOrders: result.orders });
    } catch (err) {
      return handleError(err, res, "A customer with that email already exists in this branch");
    }
  }),
);

// ── tiny error helpers ──────────────────────────────────────────────────────
class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}
function handleError(err: unknown, res: import("express").Response, uniqueMsg: string) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  // Postgres unique-violation
  if (typeof err === "object" && err && (err as { code?: string }).code === "23505") {
    return res.status(409).json({ error: uniqueMsg });
  }
  throw err;
}