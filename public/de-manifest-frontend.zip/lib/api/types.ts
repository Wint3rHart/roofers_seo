// Shared API types — mirror the real Prep Max backend (not the earlier
// hypothetical /api/v1 contract). The backend uses session cookies (no Bearer
// tokens) and is branch-isolated. See backend/ for the source of truth.

// ── Auth ────────────────────────────────────────────────────────────────────
export type StaffRole = 'super_admin' | 'branch_manager';
export type PrincipalKind = 'user' | 'customer';

export interface Principal {
  kind: PrincipalKind;
  role?: StaffRole;              // staff only
  branchId: string | null;
  email: string;
  fullName: string;
  permissions?: string[];       // staff only — effective permission keys
}

// ── Public tracking (no auth) ───────────────────────────────────────────────
export type ShipmentStatus =
  | 'info_received'
  | 'in_transit'
  | 'out_for_delivery'
  | 'delivered'
  | 'exception'
  | 'unknown';

export interface PublicTrackingEvent {
  timestamp: string | null;
  location: string | null;
  description: string;
}

export interface PublicTracking {
  trackingCode: string;
  status: ShipmentStatus | null;
  statusText: string | null;
  destinationCity: string | null;
  destinationCountry: string | null;
  estimatedDelivery: string | null;
  lastUpdated: string | null;
  pieceCount: number;
  events: PublicTrackingEvent[];
}

// ── Orders (portal + staff share most of this shape) ────────────────────────
export type OrderStatus =
  | 'pending_approval'
  | 'awaiting_carrier'
  | 'active'
  | 'delivered'
  | 'cancelled';

export const complaintCategories = [
  'Delayed shipment',
  'Damaged package',
  'Missing items',
  'Wrong delivery address',
  'Billing / pricing issue',
  'Poor customer service',
  'Other',
] as const;

export type ComplaintCategory = (typeof complaintCategories)[number];

export type ComplaintStatus = 'open' | 'in_review' | 'resolved' | 'closed';

export interface Complaint {
  id: string;
  publicId: string;
  orderPublicId: string;
  trackingCode: string;
  category: ComplaintCategory;
  message: string;
  status: ComplaintStatus;
  createdAt: string;
  updatedAt?: string;
  response?: string | null;
}

export interface OrderListItem {
  publicId: string;
  trackingCode: string;
  orderStatus: OrderStatus;
  currentStatus: ShipmentStatus | null;
  receiverCity: string | null;
  receiverCountry: string | null;
  createdVia?: 'customer' | 'staff';
  createdAt: string;
}

// ── Quotes ───────────────────────────────────────────────────────────────────
export type QuoteStatus = 'new' | 'quoted' |  'closed';

export interface QuoteItem {
  description: string;
  quantity: number;
  unitValue?: number;
}

export interface QuoteBox {
  parcelType: string;
  weightKg: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
  items: QuoteItem[];
}

export interface Quote {
  publicId: string;
  originCountry: string;
  destinationCountry: string;
  serviceLevel: string;
  contentsNature: 'documents' | 'merchandise' | null;
  boxes: QuoteBox[];
  notes: string | null;
  status: QuoteStatus;
  quotedPrice: number | null;
  quotedCurrency: string | null;
  staffResponse: string | null;
  createdAt: string;
  updatedAt: string;
}

// ── Conversation messages (shared shape across quotes + complaints) ─────────
export type MessageSender = 'customer' | 'staff';

export interface QuoteMessage {
  publicId: string;
  quotePublicId: string;
  sender: MessageSender;
  authorName: string | null;
  authorEmail: string | null;
  body: string;
  createdAt: string;
}

export interface ComplaintMessage {
  publicId: string;
  complaintPublicId: string;
  sender: MessageSender;
  authorName: string | null;
  authorEmail: string | null;
  body: string;
  createdAt: string;
}

// ── Finance (AR/AP subsidiary ledger) ───────────────────────────────────────
export type VendorType = 'carrier' | 'local' | 'other';
export type InvoiceStatus = 'draft' | 'unpaid' | 'partial' | 'paid' | 'void';
export type VendorBillStatus = 'unpaid' | 'partial' | 'paid' | 'void';
export type PaymentDirection = 'in' | 'out';
export type PaymentMethod = 'cash' | 'bank' | 'cheque' | 'online' | 'other';
export type PaymentAccount = 'cash_in_hand' | 'bank';
export type ExpenseCategory =
  | 'office_rent' | 'salaries' | 'fuel' | 'utilities' | 'marketing' | 'miscellaneous';
export type ReportPeriod = 'daily' | 'monthly' | 'yearly';

export interface Vendor {
  publicId: string;
  name: string;
  code: string | null;
  vendorType: VendorType;
  contactName: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  openingBalance: number;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
}

export interface Invoice {
  publicId: string;
  invoiceNo: string;
  customerPublicId: string;
  customerName: string | null;
  orderPublicId: string | null;
  branchPublicId: string;
  isCreditNote: boolean;
  issueDate: string;
  dueDate: string | null;
  currency: string;
  subtotal: number;
  tax: number;
  total: number;
  amountPaid: number;
  status: InvoiceStatus;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  items?: InvoiceItem[];
}

export interface VendorBillItem {
  description: string;
  amount: number;
  orderPublicId: string | null;
}

export interface VendorBill {
  publicId: string;
  billNo: string | null;
  vendorPublicId: string;
  vendorName: string;
  billDate: string;
  dueDate: string | null;
  currency: string;
  subtotal: number;
  tax: number;
  total: number;
  amountPaid: number;
  status: VendorBillStatus;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  items?: VendorBillItem[];
}

export interface Payment {
  publicId: string;
  direction: PaymentDirection;
  method: PaymentMethod;
  account: PaymentAccount;
  amount: number;
  paidOn: string;
  customerPublicId: string | null;
  customerName: string | null;
  vendorPublicId: string | null;
  vendorName: string | null;
  invoicePublicId: string | null;
  invoiceNo: string | null;
  vendorBillPublicId: string | null;
  billNo: string | null;
  reference: string | null;
  notes: string | null;
  createdAt: string;
}

export interface Expense {
  publicId: string;
  category: ExpenseCategory;
  amount: number;
  account: PaymentAccount;
  spentOn: string;
  payee: string | null;
  description: string | null;
  reference: string | null;
  createdAt: string;
}

export interface FinanceDashboard {
  totalIncome: number;
  totalExpenses: number;
  pendingPayments: number;
  pendingVendorBills: number;
  profitLoss: number;
  cashInHand: number;
  bankBalance: number;
  invoiceCount: number;
  unpaidInvoiceCount: number;
  vendorBillCount: number;
  unpaidVendorBillCount: number;
}

export interface LedgerEntry {
  date: string;
  reference: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
}

export interface Ledger {
  entries: LedgerEntry[];
  closingBalance: number;
}

export interface FinanceReportRow {
  bucket: string;
  income: number;
  expensePayments: number;
  expenses: number;
  net: number;
}

// ── Error envelope ──────────────────────────────────────────────────────────
export interface ApiError {
  error: string;
  details?: unknown;
}


export type ManifestStatus = 'open' | 'closed' | 'dispatched';

export interface ManifestShipment {
  orderPublicId: string;
  trackingCode: string;
  senderName: string | null;
  receiverName: string | null;
  destination: string | null;
  weightKg: number;
  charges: number;
  currency: string;
  orderStatus: string;
}

export interface Manifest {
  publicId: string;
  manifestNo: string;
  branchPublicId: string;
  vendorPublicId: string | null;
  vendorName: string | null;
  manifestDate: string;
  status: ManifestStatus;
  totalShipments: number;
  totalWeightKg: number;
  notes: string | null;
  createdAt: string;
  updatedAt: string;
  dispatchedAt: string | null;
  shipments?: ManifestShipment[];
}

export interface EligibleOrder {
  publicId: string;
  trackingCode: string;
  receiverName: string | null;
  destination: string | null;
  weightKg: number;
}

// ── De-Manifest (inbound receiving & reconciliation) ────────────────────────
export type DeManifestStatus = 'open' | 'completed';
export type ShipmentCondition = 'good' | 'damaged' | 'missing' | 'open_package';
export type Reconciliation = 'pending' | 'received' | 'missing' | 'extra' | 'hold';

export interface DeManifestShipment {
  id: string;
  orderPublicId: string | null;
  scannedTracking: string;
  senderName: string | null;
  receiverName: string | null;
  destination: string | null;
  receivedAt: string | null;
  condition: ShipmentCondition | null;
  reconciliation: Reconciliation;
  remarks: string | null;
}

export interface DeManifest {
  publicId: string;
  deManifestNo: string;
  branchPublicId: string;
  sourceManifestPublicId: string | null;
  sourceManifestNo: string | null;
  vendorPublicId: string | null;
  vendorName: string | null;
  courierName: string | null;
  deManifestDate: string;
  status: DeManifestStatus;
  totalExpected: number;
  totalReceived: number;
  totalMissing: number;
  totalExtra: number;
  totalDamaged: number;
  remarks: string | null;
  createdAt: string;
  updatedAt: string;
  completedAt: string | null;
  shipments?: DeManifestShipment[];
}
