// De-Manifest API client — inbound receiving & reconciliation batches.
// Routes go through the BFF proxy at /api/bff/de-manifests/* (session-cookie
// auth, branch-isolated by RLS), same pattern as lib/api/manifests.ts.

import { apiFetch } from './client';
import type {
  DeManifest, DeManifestStatus, ShipmentCondition, Reconciliation,
} from './types';

// ── List / get ───────────────────────────────────────────────────────────
export function listDeManifests(
  opts: { status?: DeManifestStatus | 'all'; q?: string; branchPublicId?: string } = {},
): Promise<DeManifest[]> {
  const params = new URLSearchParams();
  if (opts.status && opts.status !== 'all') params.set('status', opts.status);
  if (opts.q) params.set('q', opts.q);
  if (opts.branchPublicId) params.set('branchPublicId', opts.branchPublicId);
  const qs = params.toString();
  return apiFetch<{ deManifests: DeManifest[] }>(`/de-manifests${qs ? `?${qs}` : ''}`).then((r) => r.deManifests);
}

export function getDeManifest(publicId: string): Promise<DeManifest> {
  return apiFetch<{ deManifest: DeManifest }>(`/de-manifests/${publicId}`).then((r) => r.deManifest);
}

// ── Create / update header ──────────────────────────────────────────────
export interface CreateDeManifestInput {
  branchPublicId?: string;
  sourceManifestPublicId?: string;
  vendorPublicId?: string;
  courierName?: string;
  deManifestDate?: string;
  remarks?: string;
}
export function createDeManifest(body: CreateDeManifestInput): Promise<{ deManifest: DeManifest }> {
  return apiFetch('/de-manifests', { method: 'POST', body });
}

export interface UpdateDeManifestInput {
  vendorPublicId?: string | null;
  courierName?: string;
  deManifestDate?: string;
  remarks?: string;
}
export function updateDeManifest(publicId: string, body: UpdateDeManifestInput): Promise<{ deManifest: DeManifest }> {
  return apiFetch(`/de-manifests/${publicId}`, { method: 'PATCH', body });
}

// ── Shipments (scan / update / remove) ──────────────────────────────────
export interface ScanShipmentInput {
  trackingCode: string;
  condition?: ShipmentCondition;
  remarks?: string;
}
export function scanShipment(publicId: string, body: ScanShipmentInput): Promise<{ deManifest: DeManifest }> {
  return apiFetch(`/de-manifests/${publicId}/shipments`, { method: 'POST', body });
}

export interface UpdateShipmentInput {
  condition?: ShipmentCondition;
  reconciliation?: Reconciliation;
  remarks?: string;
}
export function updateShipment(
  publicId: string,
  shipmentId: string,
  body: UpdateShipmentInput,
): Promise<{ deManifest: DeManifest }> {
  return apiFetch(`/de-manifests/${publicId}/shipments/${shipmentId}`, { method: 'PATCH', body });
}

export function removeShipment(publicId: string, shipmentId: string): Promise<{ deManifest: DeManifest }> {
  return apiFetch(`/de-manifests/${publicId}/shipments/${shipmentId}`, { method: 'DELETE' });
}

// ── Lifecycle ────────────────────────────────────────────────────────────
export function completeDeManifest(publicId: string): Promise<{ deManifest: DeManifest }> {
  return apiFetch(`/de-manifests/${publicId}/complete`, { method: 'POST' });
}
