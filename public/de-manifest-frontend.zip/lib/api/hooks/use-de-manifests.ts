'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import * as deManifestsApi from '@/lib/api/de-manifests';
import type { DeManifestStatus } from '@/lib/api/types';

// Invalidate everything de-manifest-related — used by every mutation.
const DE_MANIFEST_KEY = ['de-manifests'];

// ── List / get ───────────────────────────────────────────────────────────
export function useDeManifests(opts: { status?: DeManifestStatus | 'all'; q?: string; branchPublicId?: string } = {}) {
  return useQuery({
    queryKey: ['de-manifests', 'list', opts.status ?? 'all', opts.q ?? '', opts.branchPublicId ?? ''],
    queryFn: () => deManifestsApi.listDeManifests(opts),
  });
}

export function useDeManifest(publicId: string | null) {
  return useQuery({
    queryKey: ['de-manifests', 'detail', publicId],
    queryFn: () => deManifestsApi.getDeManifest(publicId!),
    enabled: !!publicId,
  });
}

// ── Create / update header ──────────────────────────────────────────────
export function useCreateDeManifest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: deManifestsApi.CreateDeManifestInput) => deManifestsApi.createDeManifest(body),
    onSuccess: () => qc.invalidateQueries({ queryKey: DE_MANIFEST_KEY }),
  });
}

export function useUpdateDeManifest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ publicId, body }: { publicId: string; body: deManifestsApi.UpdateDeManifestInput }) =>
      deManifestsApi.updateDeManifest(publicId, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: DE_MANIFEST_KEY }),
  });
}

// ── Shipments ────────────────────────────────────────────────────────────
export function useScanShipment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ publicId, body }: { publicId: string; body: deManifestsApi.ScanShipmentInput }) =>
      deManifestsApi.scanShipment(publicId, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: DE_MANIFEST_KEY }),
  });
}

export function useUpdateShipment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ publicId, shipmentId, body }: { publicId: string; shipmentId: string; body: deManifestsApi.UpdateShipmentInput }) =>
      deManifestsApi.updateShipment(publicId, shipmentId, body),
    onSuccess: () => qc.invalidateQueries({ queryKey: DE_MANIFEST_KEY }),
  });
}

export function useRemoveShipment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ publicId, shipmentId }: { publicId: string; shipmentId: string }) =>
      deManifestsApi.removeShipment(publicId, shipmentId),
    onSuccess: () => qc.invalidateQueries({ queryKey: DE_MANIFEST_KEY }),
  });
}

// ── Lifecycle ────────────────────────────────────────────────────────────
export function useCompleteDeManifest() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (publicId: string) => deManifestsApi.completeDeManifest(publicId),
    onSuccess: () => qc.invalidateQueries({ queryKey: DE_MANIFEST_KEY }),
  });
}
