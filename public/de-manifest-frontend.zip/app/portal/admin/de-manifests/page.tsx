'use client';

import { Suspense, useState } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { PlusCircle, ArrowRight, PackageOpen, X } from 'lucide-react';
import { useDeManifests, useCreateDeManifest } from '@/lib/api/hooks/use-de-manifests';
import { useManifests } from '@/lib/api/hooks/use-manifests';
import { useVendors } from '@/lib/api/hooks/use-finance';
import { useMe } from '@/lib/api/hooks/use-auth';
import { useBranches } from '@/lib/api/hooks/use-admin';
import type { DeManifestStatus } from '@/lib/api/types';
import { SearchBar } from '@/components/admin/SearchBar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const FILTERS: { key: DeManifestStatus | ''; label: string }[] = [
  { key: '', label: 'All' },
  { key: 'open', label: 'Open' },
  { key: 'completed', label: 'Completed' },
];

function StatusPill({ status }: { status: DeManifestStatus }) {
  const map: Record<DeManifestStatus, string> = {
    open: 'bg-amber-100 text-amber-700',
    completed: 'bg-green-100 text-green-700',
  };
  return (
    <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold capitalize', map[status])}>
      {status}
    </span>
  );
}

// Branch picker shown for super_admin users only — mirrors manifests/page.tsx BranchField.
function BranchField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const { data: branches } = useBranches();
  if (!branches) return null;
  return (
    <div>
      <label className="text-xs font-medium text-gray-600">Arrival hub (branch) *</label>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="mt-1 h-10 w-full rounded-lg border border-gray-300 bg-white px-3 text-sm"
      >
        <option value="">Select a branch…</option>
        {branches.map((b) => <option key={b.publicId} value={b.publicId}>{b.name} — {b.city}</option>)}
      </select>
    </div>
  );
}

function CreateDeManifestForm({ onDone }: { onDone: (publicId: string) => void }) {
  const create = useCreateDeManifest();
  const { data: me } = useMe();
  const isSuper = me?.role === 'super_admin';
  const [branchPublicId, setBranchPublicId] = useState('');
  const [sourceManifestPublicId, setSourceManifestPublicId] = useState('');
  const [vendorPublicId, setVendorPublicId] = useState('');
  const [courierName, setCourierName] = useState('');
  const [deManifestDate, setDeManifestDate] = useState(new Date().toISOString().slice(0, 10));
  const [remarks, setRemarks] = useState('');

  const { data: vendors } = useVendors({
    activeOnly: true,
    branchPublicId: isSuper ? (branchPublicId || undefined) : undefined,
  });

  // Optional link to a known outbound manifest (the "expected" list) —
  // dispatched manifests are the sensible pool to reconcile a receiving
  // batch against.
  const { data: dispatchedManifests } = useManifests({ status: 'dispatched' });

  function handleBranchChange(v: string) {
    setBranchPublicId(v);
    setVendorPublicId('');
  }

  async function submit() {
    if (create.isPending) return;
    if (isSuper && !branchPublicId) return;
    const res = await create.mutateAsync({
      ...(isSuper && branchPublicId ? { branchPublicId } : {}),
      sourceManifestPublicId: sourceManifestPublicId || undefined,
      vendorPublicId: vendorPublicId || undefined,
      courierName: courierName.trim() || undefined,
      deManifestDate,
      remarks: remarks.trim() || undefined,
    });
    onDone(res.deManifest.publicId);
  }

  return (
    <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4">
      <div className="mb-3 flex items-center justify-between">
        <h2 className="text-sm font-semibold text-gray-800">New de-manifest</h2>
        <button onClick={() => onDone('')} className="text-gray-400 hover:text-gray-700"><X className="h-4 w-4" /></button>
      </div>
      <div className="grid gap-2 sm:grid-cols-3">
        {isSuper && <BranchField value={branchPublicId} onChange={handleBranchChange} />}
        <div>
          <label className="text-xs font-medium text-gray-600">Source manifest (optional)</label>
          <select
            value={sourceManifestPublicId}
            onChange={(e) => setSourceManifestPublicId(e.target.value)}
            className="mt-1 h-10 w-full rounded-lg border border-gray-300 bg-white px-3 text-sm"
          >
            <option value="">— None / manual receiving —</option>
            {dispatchedManifests?.map((m) => (
              <option key={m.publicId} value={m.publicId}>{m.manifestNo} ({m.totalShipments} shipments)</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-gray-600">Vendor / Carrier</label>
          <select
            value={vendorPublicId}
            onChange={(e) => setVendorPublicId(e.target.value)}
            disabled={isSuper && !branchPublicId}
            className="mt-1 h-10 w-full rounded-lg border border-gray-300 bg-white px-3 text-sm disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="">{isSuper && !branchPublicId ? 'Select a branch first…' : 'Select later…'}</option>
            {vendors?.map((v) => <option key={v.publicId} value={v.publicId}>{v.name}</option>)}
          </select>
        </div>
        <div>
          <label className="text-xs font-medium text-gray-600">Courier name (if no vendor record)</label>
          <Input value={courierName} onChange={(e) => setCourierName(e.target.value)} placeholder="Optional free text" className="mt-1" />
        </div>
        <div>
          <label className="text-xs font-medium text-gray-600">De-manifest date</label>
          <Input type="date" value={deManifestDate} onChange={(e) => setDeManifestDate(e.target.value)} className="mt-1" />
        </div>
        <div className="sm:col-span-3">
          <label className="text-xs font-medium text-gray-600">Remarks</label>
          <Input value={remarks} onChange={(e) => setRemarks(e.target.value)} placeholder="Optional" className="mt-1" />
        </div>
      </div>
      <div className="mt-3 flex justify-end gap-2">
        <Button variant="ghost" onClick={() => onDone('')}>Cancel</Button>
        <Button onClick={submit} disabled={(isSuper && !branchPublicId) || create.isPending}>
          {create.isPending ? 'Creating…' : 'Create de-manifest'}
        </Button>
      </div>
      {create.isError && <p className="mt-2 text-xs text-error">Couldn&apos;t create de-manifest. Please try again.</p>}
    </div>
  );
}

function DeManifestsContent() {
  const params = useSearchParams();
  const status = (params.get('status') ?? '') as DeManifestStatus | '';
  const [search, setSearch] = useState('');
  const [showCreate, setShowCreate] = useState(false);
  const { data: deManifests, isLoading } = useDeManifests({ status: status || undefined, q: search || undefined });

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <PackageOpen className="h-6 w-6 text-primary" />
          <h1 className="text-2xl font-bold">De-Manifests</h1>
        </div>
        {!showCreate && (
          <Button className="gap-1.5" onClick={() => setShowCreate(true)}>
            <PlusCircle className="h-4 w-4" /> New De-Manifest
          </Button>
        )}
      </div>
      <p className="mb-4 text-sm text-gray-500">
        Inbound receiving — reconcile what physically arrives against what was expected. Optionally link a dispatched manifest, then scan shipments in.
      </p>

      {showCreate && (
        <CreateDeManifestForm
          onDone={(publicId) => {
            setShowCreate(false);
            if (publicId) window.location.href = `/portal/admin/de-manifests/${publicId}`;
          }}
        />
      )}

      <SearchBar onChange={setSearch} placeholder="Search de-manifest no. or courier…" className="mb-4 max-w-md" />

      <div className="mb-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <Link
            key={f.key}
            href={f.key ? `/portal/admin/de-manifests?status=${f.key}` : '/portal/admin/de-manifests'}
            className={cn(
              'rounded-full px-3.5 py-1.5 text-sm font-medium transition',
              status === f.key ? 'bg-primary text-black' : 'bg-white text-gray-600 border border-gray-200 hover:border-primary/40',
            )}
          >
            {f.label}
          </Link>
        ))}
      </div>

      {isLoading ? (
        <div className="space-y-3">{[1, 2, 3, 4].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-gray-200" />)}</div>
      ) : !deManifests || deManifests.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-12 text-center text-gray-500">
          {search ? `No de-manifests match “${search}”.` : 'No de-manifests yet.'}
        </div>
      ) : (
        <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-4 py-3">De-Manifest No.</th>
                <th className="px-4 py-3">Courier</th>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3 text-right">Received</th>
                <th className="px-4 py-3 text-right">Missing</th>
                <th className="px-4 py-3 text-right">Extra</th>
                <th className="px-4 py-3 text-right">Damaged</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {deManifests.map((m) => (
                <tr key={m.publicId} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium">
                    <Link href={`/portal/admin/de-manifests/${m.publicId}`} className="hover:text-primary">{m.deManifestNo}</Link>
                  </td>
                  <td className="px-4 py-3 text-gray-600">{m.vendorName ?? m.courierName ?? '—'}</td>
                  <td className="px-4 py-3 text-gray-500">{new Date(m.deManifestDate).toLocaleDateString('en-GB')}</td>
                  <td className="px-4 py-3 text-right">{m.totalReceived}</td>
                  <td className="px-4 py-3 text-right">{m.totalMissing > 0 ? <span className="font-semibold text-red-600">{m.totalMissing}</span> : 0}</td>
                  <td className="px-4 py-3 text-right">{m.totalExtra > 0 ? <span className="font-semibold text-amber-600">{m.totalExtra}</span> : 0}</td>
                  <td className="px-4 py-3 text-right">{m.totalDamaged > 0 ? <span className="font-semibold text-red-600">{m.totalDamaged}</span> : 0}</td>
                  <td className="px-4 py-3"><StatusPill status={m.status} /></td>
                  <td className="px-4 py-3 text-right">
                    <Link href={`/portal/admin/de-manifests/${m.publicId}`}><ArrowRight className="inline h-4 w-4 text-gray-400" /></Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminDeManifestsPage() {
  return <Suspense fallback={<div className="h-64" />}><DeManifestsContent /></Suspense>;
}
