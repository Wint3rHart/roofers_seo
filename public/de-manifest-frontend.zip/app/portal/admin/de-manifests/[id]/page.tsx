'use client';

import { useEffect, useRef, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft, PackageOpen, Trash2, CheckCircle2, ScanLine, CameraOff, X,
} from 'lucide-react';
import {
  useDeManifest, useUpdateDeManifest, useScanShipment, useUpdateShipment,
  useRemoveShipment, useCompleteDeManifest,
} from '@/lib/api/hooks/use-de-manifests';
import { useVendors } from '@/lib/api/hooks/use-finance';
import type { DeManifestStatus, ShipmentCondition, Reconciliation } from '@/lib/api/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

function dateStr(s: string | null): string {
  if (!s) return '—';
  return new Date(s).toLocaleDateString('en-GB');
}
function dateTimeStr(s: string | null): string {
  if (!s) return '—';
  return new Date(s).toLocaleString('en-GB');
}

function StatusPill({ status }: { status: DeManifestStatus }) {
  const map: Record<DeManifestStatus, string> = {
    open: 'bg-amber-100 text-amber-700',
    completed: 'bg-green-100 text-green-700',
  };
  return (
    <span className={cn('inline-block rounded-full px-3 py-1 text-xs font-semibold capitalize', map[status])}>
      {status}
    </span>
  );
}

const RECONCILIATION_STYLES: Record<Reconciliation, string> = {
  pending: 'bg-gray-100 text-gray-600',
  received: 'bg-green-100 text-green-700',
  missing: 'bg-red-100 text-red-700',
  extra: 'bg-amber-100 text-amber-700',
  hold: 'bg-blue-100 text-blue-700',
};

function ReconciliationPill({ value }: { value: Reconciliation }) {
  return (
    <span className={cn('inline-block rounded-full px-2.5 py-0.5 text-xs font-semibold capitalize', RECONCILIATION_STYLES[value])}>
      {value}
    </span>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center text-gray-500">
      {label}
    </div>
  );
}

// ── Barcode/QR scanner modal ────────────────────────────────────────────
// Uses the browser-native BarcodeDetector API — same house pattern as the
// manifest module's scanner. Difference: here every detected code is POSTed
// straight to the scan endpoint (matched or not — the backend classifies
// unmatched codes as 'extra' itself), so there's no local eligibility lookup.
type ScanFeedback = { code: string; kind: 'received' | 'extra' | 'error' } | null;

function BarcodeScannerModal({
  onScan,
  onClose,
}: {
  onScan: (code: string) => Promise<'received' | 'extra' | 'error'>;
  onClose: () => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const rafRef = useRef<number | null>(null);
  const lastCodeRef = useRef<{ code: string; at: number } | null>(null);
  const [supported, setSupported] = useState(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<ScanFeedback>(null);
  const [scanCount, setScanCount] = useState(0);

  useEffect(() => {
    if (!('BarcodeDetector' in window)) {
      setSupported(false);
      return;
    }

    let cancelled = false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const Detector = (window as any).BarcodeDetector;
    const detector = new Detector({
      formats: ['qr_code', 'code_128', 'code_39', 'ean_13', 'ean_8', 'upc_a', 'upc_e'],
    });

    async function start() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        if (cancelled) { stream.getTracks().forEach((t) => t.stop()); return; }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
        }
        tick();
      } catch {
        setCameraError('Could not access the camera. Check browser permissions, or use the text field instead.');
      }
    }

    async function tick() {
      if (cancelled || !videoRef.current) return;
      try {
        const codes = await detector.detect(videoRef.current);
        if (codes.length > 0) {
          const raw = String(codes[0].rawValue ?? '').trim();
          handleDetected(raw);
        }
      } catch {
        // transient decode errors are normal mid-frame; ignore and keep scanning
      }
      rafRef.current = requestAnimationFrame(tick);
    }

    async function handleDetected(code: string) {
      if (!code) return;
      const now = Date.now();
      if (lastCodeRef.current && lastCodeRef.current.code === code && now - lastCodeRef.current.at < 2000) return;
      lastCodeRef.current = { code, at: now };
      setScanCount((c) => c + 1);
      const kind = await onScan(code);
      setFeedback({ code, kind });
    }

    start();
    return () => {
      cancelled = true;
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!feedback) return;
    const t = setTimeout(() => setFeedback(null), 1400);
    return () => clearTimeout(t);
  }, [feedback]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="w-full max-w-md rounded-2xl bg-white p-4">
        <div className="mb-3 flex items-center justify-between">
          <h3 className="flex items-center gap-1.5 text-sm font-semibold text-gray-800">
            <ScanLine className="h-4 w-4" /> Scan tracking barcode
          </h3>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-700"><X className="h-4 w-4" /></button>
        </div>

        {!supported ? (
          <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-gray-300 p-8 text-center text-sm text-gray-500">
            <CameraOff className="h-6 w-6 text-gray-400" />
            Barcode scanning isn&apos;t supported in this browser. Try Chrome or Edge, or use the text field below instead.
          </div>
        ) : cameraError ? (
          <div className="flex flex-col items-center gap-2 rounded-xl border border-dashed border-gray-300 p-8 text-center text-sm text-gray-500">
            <CameraOff className="h-6 w-6 text-gray-400" />
            {cameraError}
          </div>
        ) : (
          <>
            <div className="relative overflow-hidden rounded-xl bg-black">
              <video ref={videoRef} className="aspect-[4/3] w-full object-cover" muted playsInline />
              <div className="pointer-events-none absolute inset-8 rounded-lg border-2 border-white/70" />
              {feedback && (
                <div
                  className={cn(
                    'absolute inset-x-0 bottom-0 flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-white',
                    feedback.kind === 'received' && 'bg-green-600/90',
                    feedback.kind === 'extra' && 'bg-amber-600/90',
                    feedback.kind === 'error' && 'bg-red-600/90',
                  )}
                >
                  <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                  {feedback.kind === 'received' && `Received ${feedback.code}`}
                  {feedback.kind === 'extra' && `${feedback.code} not recognised — logged as extra`}
                  {feedback.kind === 'error' && `Couldn't record ${feedback.code}`}
                </div>
              )}
            </div>
            <p className="mt-2 text-center text-xs text-gray-500">
              {scanCount === 0 ? 'Point the camera at a tracking barcode or QR code.' : `${scanCount} scan${scanCount === 1 ? '' : 's'} so far — keep scanning or close when done.`}
            </p>
          </>
        )}

        <Button variant="outline" className="mt-3 w-full" onClick={onClose}>Done scanning</Button>
      </div>
    </div>
  );
}

// ── Scan panel — text entry + camera scan, both hit the same endpoint ─────
function ScanPanel({ publicId }: { publicId: string }) {
  const [code, setCode] = useState('');
  const [showScanner, setShowScanner] = useState(false);
  const scan = useScanShipment();
  const inputRef = useRef<HTMLInputElement>(null);

  async function submitScan(trackingCode: string): Promise<'received' | 'extra' | 'error'> {
    if (!trackingCode.trim()) return 'error';
    try {
      const res = await scan.mutateAsync({ publicId, body: { trackingCode: trackingCode.trim() } });
      const row = res.deManifest.shipments?.find((s) => s.scannedTracking === trackingCode.trim());
      return row?.orderPublicId ? 'received' : 'extra';
    } catch {
      return 'error';
    }
  }

  async function handleTextSubmit() {
    const c = code.trim();
    if (!c) return;
    await submitScan(c);
    setCode('');
    inputRef.current?.focus();
  }

  return (
    <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4">
      <h2 className="mb-3 text-sm font-semibold text-gray-800">Scan / receive a shipment</h2>
      <div className="flex gap-2">
        <Input
          ref={inputRef}
          value={code}
          onChange={(e) => setCode(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') handleTextSubmit(); }}
          placeholder="Type or scan a tracking number, then Enter…"
          className="flex-1"
        />
        <Button onClick={handleTextSubmit} disabled={!code.trim() || scan.isPending}>
          {scan.isPending ? 'Adding…' : 'Add'}
        </Button>
        <Button type="button" variant="outline" className="shrink-0 gap-1.5" onClick={() => setShowScanner(true)}>
          <ScanLine className="h-4 w-4" /> Camera
        </Button>
      </div>
      <p className="mt-2 text-xs text-gray-500">
        A matched tracking code is marked <span className="font-semibold text-green-700">received</span>. An unrecognised one is logged as <span className="font-semibold text-amber-700">extra</span> — nothing is silently dropped.
      </p>

      {showScanner && (
        <BarcodeScannerModal onScan={submitScan} onClose={() => setShowScanner(false)} />
      )}
    </div>
  );
}

// ── Editable condition / reconciliation cells (open only) ─────────────────
const CONDITIONS: ShipmentCondition[] = ['good', 'damaged', 'missing', 'open_package'];
const RECONCILIATIONS: Reconciliation[] = ['pending', 'received', 'missing', 'extra', 'hold'];

function ShipmentRow({
  publicId,
  shipment,
  editable,
}: {
  publicId: string;
  shipment: {
    id: string; orderPublicId: string | null; scannedTracking: string;
    senderName: string | null; receiverName: string | null; destination: string | null;
    receivedAt: string | null; condition: ShipmentCondition | null; reconciliation: Reconciliation; remarks: string | null;
  };
  editable: boolean;
}) {
  const updateShipment = useUpdateShipment();
  const removeShipment = useRemoveShipment();

  return (
    <tr className="hover:bg-gray-50">
      <td className="px-4 py-3 font-medium">
        {shipment.orderPublicId ? (
          <Link href={`/portal/admin/orders/${shipment.orderPublicId}`} className="hover:text-primary">{shipment.scannedTracking}</Link>
        ) : (
          <span className="text-gray-500">{shipment.scannedTracking}</span>
        )}
      </td>
      <td className="px-4 py-3 text-gray-600">{shipment.senderName ?? '—'}</td>
      <td className="px-4 py-3 text-gray-600">{shipment.receiverName ?? '—'}</td>
      <td className="px-4 py-3 text-gray-600">{shipment.destination ?? '—'}</td>
      <td className="px-4 py-3 text-gray-500">{dateTimeStr(shipment.receivedAt)}</td>
      <td className="px-4 py-3">
        {editable ? (
          <select
            value={shipment.condition ?? ''}
            onChange={(e) => updateShipment.mutate({ publicId, shipmentId: shipment.id, body: { condition: (e.target.value || undefined) as ShipmentCondition | undefined } })}
            className="h-8 rounded-lg border border-gray-300 bg-white px-2 text-xs capitalize"
          >
            <option value="">—</option>
            {CONDITIONS.map((c) => <option key={c} value={c}>{c.replace('_', ' ')}</option>)}
          </select>
        ) : (
          <span className="text-xs capitalize text-gray-600">{shipment.condition?.replace('_', ' ') ?? '—'}</span>
        )}
      </td>
      <td className="px-4 py-3">
        {editable ? (
          <select
            value={shipment.reconciliation}
            onChange={(e) => updateShipment.mutate({ publicId, shipmentId: shipment.id, body: { reconciliation: e.target.value as Reconciliation } })}
            className="h-8 rounded-lg border border-gray-300 bg-white px-2 text-xs capitalize"
          >
            {RECONCILIATIONS.map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
        ) : (
          <ReconciliationPill value={shipment.reconciliation} />
        )}
      </td>
      <td className="px-4 py-3 text-gray-500">{shipment.remarks ?? '—'}</td>
      {editable && (
        <td className="px-4 py-3 text-right">
          <Button
            size="sm"
            variant="ghost"
            disabled={removeShipment.isPending}
            onClick={() => { if (confirm(`Remove ${shipment.scannedTracking} from this de-manifest?`)) removeShipment.mutate({ publicId, shipmentId: shipment.id }); }}
          >
            <Trash2 className="h-3.5 w-3.5 text-red-500" />
          </Button>
        </td>
      )}
    </tr>
  );
}

function DeManifestDetailContent({ publicId }: { publicId: string }) {
  const { data: deManifest, isLoading } = useDeManifest(publicId);
  const { data: vendors } = useVendors({ activeOnly: true, branchPublicId: deManifest?.branchPublicId });
  const updateDeManifest = useUpdateDeManifest();
  const completeDeManifest = useCompleteDeManifest();

  const [editingRemarks, setEditingRemarks] = useState(false);
  const [remarksDraft, setRemarksDraft] = useState('');

  if (isLoading) {
    return <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-16 animate-pulse rounded-xl bg-gray-200" />)}</div>;
  }
  if (!deManifest) {
    return <EmptyState label="De-manifest not found." />;
  }

  const isOpen = deManifest.status === 'open';

  async function saveVendor(vendorPublicId: string) {
    await updateDeManifest.mutateAsync({ publicId, body: { vendorPublicId: vendorPublicId || null } });
  }

  async function saveRemarks() {
    await updateDeManifest.mutateAsync({ publicId, body: { remarks: remarksDraft } });
    setEditingRemarks(false);
  }

  return (
    <div>
      <Link href="/portal/admin/de-manifests" className="mb-4 inline-flex items-center gap-1.5 text-sm text-gray-500 hover:text-primary">
        <ArrowLeft className="h-4 w-4" /> Back to de-manifests
      </Link>

      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <PackageOpen className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-2xl font-bold">{deManifest.deManifestNo}</h1>
            <p className="text-sm text-gray-500">
              {dateStr(deManifest.deManifestDate)}
              {deManifest.sourceManifestNo && <> · reconciling against <span className="font-medium">{deManifest.sourceManifestNo}</span></>}
            </p>
          </div>
          <StatusPill status={deManifest.status} />
        </div>
        {isOpen && (
          <Button
            className="gap-1.5"
            disabled={completeDeManifest.isPending}
            onClick={() => { if (confirm('Complete this de-manifest? Any un-scanned expected shipments will be marked missing, and it can no longer be edited.')) completeDeManifest.mutate(publicId); }}
          >
            <CheckCircle2 className="h-4 w-4" /> {completeDeManifest.isPending ? 'Completing…' : 'Complete'}
          </Button>
        )}
      </div>

      {/* header info */}
      <div className="mb-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Vendor / Carrier</div>
          {isOpen ? (
            <select
              value={deManifest.vendorPublicId ?? ''}
              onChange={(e) => saveVendor(e.target.value)}
              className="mt-1 h-9 w-full rounded-lg border border-gray-300 bg-white px-2 text-sm"
            >
              <option value="">— Not set —</option>
              {vendors?.map((v) => <option key={v.publicId} value={v.publicId}>{v.name}</option>)}
            </select>
          ) : (
            <div className="mt-1 text-sm font-semibold">{deManifest.vendorName ?? deManifest.courierName ?? '—'}</div>
          )}
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Expected</div>
          <div className="mt-1 text-lg font-semibold">{deManifest.totalExpected}</div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Received</div>
          <div className="mt-1 text-lg font-semibold text-green-700">{deManifest.totalReceived}</div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Missing</div>
          <div className="mt-1 text-lg font-semibold text-red-600">{deManifest.totalMissing}</div>
        </div>
        <div className="rounded-xl border border-gray-200 bg-white p-4">
          <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Extra / Damaged</div>
          <div className="mt-1 text-lg font-semibold text-amber-600">{deManifest.totalExtra} / {deManifest.totalDamaged}</div>
        </div>
      </div>

      {/* remarks */}
      <div className="mb-5 rounded-xl border border-gray-200 bg-white p-4">
        <div className="mb-1 flex items-center justify-between">
          <div className="text-xs font-medium uppercase tracking-wide text-gray-400">Remarks</div>
          {isOpen && !editingRemarks && (
            <button className="text-xs text-primary-hover hover:underline" onClick={() => { setRemarksDraft(deManifest.remarks ?? ''); setEditingRemarks(true); }}>
              Edit
            </button>
          )}
        </div>
        {editingRemarks ? (
          <div className="flex gap-2">
            <Input value={remarksDraft} onChange={(e) => setRemarksDraft(e.target.value)} className="flex-1" />
            <Button size="sm" onClick={saveRemarks} disabled={updateDeManifest.isPending}>Save</Button>
            <Button size="sm" variant="ghost" onClick={() => setEditingRemarks(false)}>Cancel</Button>
          </div>
        ) : (
          <p className="text-sm text-gray-700">{deManifest.remarks || '—'}</p>
        )}
      </div>

      {/* scan panel */}
      {isOpen && <ScanPanel publicId={publicId} />}

      {/* shipments */}
      <h2 className="mb-3 text-lg font-semibold">Shipments</h2>

      {!deManifest.shipments || deManifest.shipments.length === 0 ? (
        <EmptyState label="No shipments scanned yet." />
      ) : (
        <div className="overflow-x-auto rounded-2xl border border-gray-200 bg-white">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-left text-xs uppercase tracking-wide text-gray-500">
              <tr>
                <th className="px-4 py-3">Tracking</th>
                <th className="px-4 py-3">Sender</th>
                <th className="px-4 py-3">Receiver</th>
                <th className="px-4 py-3">Destination</th>
                <th className="px-4 py-3">Received at</th>
                <th className="px-4 py-3">Condition</th>
                <th className="px-4 py-3">Reconciliation</th>
                <th className="px-4 py-3">Remarks</th>
                {isOpen && <th className="px-4 py-3" />}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {deManifest.shipments.map((s) => (
                <ShipmentRow key={s.id} publicId={publicId} shipment={s} editable={isOpen} />
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default function AdminDeManifestDetailPage() {
  const params = useParams<{ id: string }>();
  return <DeManifestDetailContent publicId={params.id} />;
}
