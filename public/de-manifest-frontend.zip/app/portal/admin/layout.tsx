'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import {
  LayoutDashboard, Package, PackageCheck, Users, UserCog, ShieldCheck,
  Inbox, Building2, LogOut, MessageSquareWarning, Calculator, Wallet, Truck, PackageOpen,
} from 'lucide-react';
import { BrandLogo } from '@/components/layout/BrandLogo';
import { NotificationBell } from '@/components/admin/NotificationBell';
import { AdminAuthShell } from '@/components/portal/admin-auth-shell';
import { AdminLoginForm } from '@/components/portal/admin-login-form';
import { useMe, useLogout } from '@/lib/api/hooks/use-auth';
import { cn } from '@/lib/utils';

// Auth sub-pages under /portal/admin render standalone (they bring their own
// AdminAuthShell) and must NOT be gated behind the dashboard's staff check.
const AUTH_PATHS = ['/portal/admin/register', '/portal/admin/forgot-password'];

interface NavItem { href: string; label: string; icon: typeof Package; exact?: boolean; needs?: string; superOnly?: boolean }

const NAV: NavItem[] = [
  { href: '/portal/admin', label: 'Dashboard', icon: LayoutDashboard, exact: true },
  { href: '/portal/admin/orders', label: 'Orders', icon: Package, needs: 'orders.view' },
  { href: '/portal/admin/order-requests', label: 'Order Requests', icon: PackageCheck, needs: 'orders.view' },
  { href: '/portal/admin/complaints', label: 'Complaints', icon: MessageSquareWarning, needs: 'complaints.view' },
  { href: '/portal/admin/quotes', label: 'Quotes', icon: Calculator, needs: 'quotes.view' },
  { href: '/portal/admin/finance', label: 'Finance', icon: Wallet, needs: 'finance.view' },
  { href: '/portal/admin/manifests', label: 'Manifests', icon: Truck, needs: 'manifest.view' },
  { href: '/portal/admin/de-manifests', label: 'De-Manifests', icon: PackageOpen, needs: 'demanifest.view' },
  { href: '/portal/admin/customers', label: 'Customers', icon: Users, needs: 'customers.view' },
  { href: '/portal/admin/requests', label: 'Account Requests', icon: Inbox, needs: 'customers.view' },
  { href: '/portal/admin/accounts', label: 'Staff Accounts', icon: UserCog, superOnly: true },
  { href: '/portal/admin/branches', label: 'Branches', icon: Building2, superOnly: true },
  { href: '/portal/admin/permissions', label: 'Permissions', icon: ShieldCheck, superOnly: true },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { data: me, isLoading } = useMe();
  const logout = useLogout();

  const isAuthPage = AUTH_PATHS.some((p) => pathname === p || pathname.startsWith(`${p}/`));

  // A logged-in customer doesn't belong in the admin panel → send to their portal.
  useEffect(() => {
    if (isLoading || isAuthPage) return;
    if (me && me.kind === 'customer') router.replace('/portal');
  }, [me, isLoading, isAuthPage, router]);

  // Standalone admin auth pages (register / forgot-password) render bare.
  if (isAuthPage) {
    return <div className="flex min-h-screen flex-col bg-black">{children}</div>;
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-off-white">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    );
  }

  // Not signed in as staff → show the admin sign-in at /portal/admin itself.
  if (!me || me.kind !== 'user') {
    return (
      <div className="flex min-h-screen flex-col bg-black">
        <AdminAuthShell
          title={<>Admin <span className="text-primary">Sign In</span></>}
          subtitle="Sign in with your Prepmax staff account to manage shipments, customers, and operations."
          footer={
            <span className="text-gray-500">
              Staff accounts are created by an administrator. Contact your super-admin if you need access.
            </span>
          }
        >
          <AdminLoginForm />
        </AdminAuthShell>
      </div>
    );
  }

  const isSuper = me.role === 'super_admin';
  const perms = new Set(me.permissions ?? []);
  const visible = NAV.filter((item) => {
    if (item.superOnly) return isSuper;
    if (item.needs) return isSuper || perms.has(item.needs);
    return true;
  });

  // Match on a path-segment boundary so "/portal/admin/orders" doesn't also
  // light up for "/portal/admin/order-requests".
  const isActive = (item: NavItem) =>
    item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`);

  return (
    <div className="min-h-screen bg-off-white">
      {/* sidebar — fixed, dark (matches the website navbar) */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-60 flex-col border-r border-white/10 bg-dark md:flex">
        <div className="border-b border-white/10 px-5 py-4"><Link href="/portal/admin"><BrandLogo size="sm" /></Link></div>
        <nav className="flex-1 space-y-1 overflow-y-auto p-3">
          {visible.map((item) => {
            const active = isActive(item);
            return (
              <Link key={item.href} href={item.href}
                className={cn('flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition',
                  active ? 'bg-primary text-black' : 'text-gray-300 hover:bg-white/10 hover:text-white')}>
                <item.icon className="h-4.5 w-4.5" /> {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-white/10 p-3">
          <div className="px-3 py-2 text-xs text-gray-400">
            {me.fullName}
            <span className="ml-1 rounded bg-white/10 px-1.5 py-0.5 text-[10px] font-semibold text-gray-200">
              {isSuper ? 'Super Admin' : 'Branch Manager'}
            </span>
          </div>
          <button onClick={async () => { await logout.mutateAsync(); router.replace('/portal/admin'); }}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-gray-300 hover:bg-white/10 hover:text-white">
            <LogOut className="h-4.5 w-4.5" /> Sign out
          </button>
        </div>
      </aside>

      {/* main (offset by the fixed sidebar on md+) */}
      <div className="flex min-h-screen min-w-0 flex-col md:pl-60">
        <header className="sticky top-0 z-20 flex items-center justify-between border-b border-gray-200 bg-white px-4 py-3 md:px-6">
          <div className="md:hidden"><BrandLogo size="sm" /></div>
          <div className="ml-auto flex items-center gap-3">
            <NotificationBell sseEnabled={!isSuper} />
          </div>
        </header>

        {/* mobile nav */}
        <div className="flex gap-1 overflow-x-auto border-b border-gray-200 bg-white px-2 py-2 md:hidden">
          {visible.map((item) => {
            const active = isActive(item);
            return (
              <Link key={item.href} href={item.href}
                className={cn('whitespace-nowrap rounded-lg px-3 py-1.5 text-xs font-medium',
                  active ? 'bg-primary/10 text-primary-hover' : 'text-gray-600')}>
                {item.label}
              </Link>
            );
          })}
        </div>

        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  );
}