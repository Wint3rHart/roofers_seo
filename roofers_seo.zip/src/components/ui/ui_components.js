import { Home } from "lucide-react";
import Link from "next/link";

 function Logo({ dark = false }) {
  return (
    <a href="/" className="group flex items-center gap-2.5">
      {/* Roof + chimney icon */}
      <svg
        viewBox="0 0 32 28"
        className="h-7 w-8 shrink-0 transition-transform group-hover:scale-110"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
      >
        {/* Open roof — V chevron, stroke only (no base line) */}
        <path
          d="M2 18 L16 6 L30 18"
          stroke="#eb5e28"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
        />
        {/* Chimney — small vertical rect on the right slope */}
        <rect x="20" y="2" width="3.5" height="9" fill="#eb5e28" />
      </svg>

      <span className="font-heading mt-1 block leading-none">
        <span
          className="block text-base font-bold tracking-tight"
          style={{ color: "#eb5e28" }}
        >
          ROOFER
        </span>
        <span
          className="block text-xs font-normal tracking-tight"
          style={{ color: dark ? "#fffcf2" : "#252422" }}
        >
          SEO CO.
        </span>
      </span>
    </a>
  );
}


function PrimaryButton({ children, className = "", as = "Link", href, ...props }) {
  const Comp = as === "Link" ? "Link" : "button";
  console.log(href);
  
  return (
    <Link
      href={href?href:'/'}
      className={`inline-flex items-center justify-center gap-2 rounded-md bg-[#eb5e28] px-6 py-3.5 text-sm font-bold text-[#fffcf2] transition-colors hover:bg-[#d94f1c] ${className}`}
      {...props}
    >
      {children}
    </Link>
  );
}

function SecondaryButton({ children, className = "", as = "Link", href, ...props }) {
  const Comp = as === "Link" ? "Link" : "button";
  return (
    <Link
      href={href}
      className={`inline-flex items-center justify-center gap-2 rounded-md border-2 border-[#252422] px-6 py-3.5 text-sm font-bold text-[#252422] transition-colors hover:bg-[#252422] hover:text-[#fffcf2] ${className}`}
      {...props}
    >
      {children}
    </Link>
  );
}

function Eyebrow({ children, className = "" }) {
  return (
    <p className={`eyebrow mb-3 text-xs font-bold tracking-[0.18em] text-[#eb5e28] uppercase ${className}`}>
      {children}
    </p>
  );
}

export { PrimaryButton, SecondaryButton, Eyebrow, Logo };
