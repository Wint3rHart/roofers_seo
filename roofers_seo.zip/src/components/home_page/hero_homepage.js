"use client";

import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Eyebrow, PrimaryButton, SecondaryButton } from "../ui/ui_components";
import HeroBackground from "../shared/hero_background";

const container = {
  hidden: {},
  show: {
    transition: {
      staggerChildren: 0.32,
      delayChildren: 0.5,
    },
  },
};

const item = {
  hidden: { opacity: 0, y: 18 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 0.55, 0.5, 1] },
  },
};

// Entrance for the hero image: fades in, slides from the right, scales up slightly.
const imageEntrance = {
  hidden: { opacity: 0, scale: 1.04 },
  show: {
    opacity: 1,
  
    scale: 1,
    transition: { duration: 1, delay: 0.2, ease: [0.22, 0.55, 0.5, 1] },
  },
};

// Gentle continuous float once the entrance finishes, for a premium ambient feel.
const imageFloat = {
  y: [0, -10, 0],
  transition: {
    duration: 6,
    delay: 1.4,
    repeat: Infinity,
    ease: "easeInOut",
  },
};

export default function Hero() {
  return (
    <section className="relative overflow-hidden border-[#ccc5b9]/60">
      <HeroBackground />
      <motion.div
        className="absolute right-0 top-0 z-[1] h-[100%] w-[100%] lg:w-[100%]"
        variants={imageEntrance}
        initial="hidden"
        animate="show"
      >
        <motion.div className="relative h-full w-full" animate={imageFloat}>
          <Image
            src="/roofer homepage.jpeg"
            alt="Aerial view of a roof with local service radius pin"
            fill
            priority
            className="object-contain object-top-right"
          />
        </motion.div>

        {/* left fade — dissolves the image into the copy side, using the
            same warm stops as HeroBackground so there's no visible seam */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(90deg, #fdf8ee 0%, rgba(253,248,238,0.85) 12%, rgba(253,248,238,0.35) 28%, transparent 45%)",
          }}
        />

        {/* bottom fade — settles the image into the darker/warmer base of
            the gradient instead of ending on a hard sky edge */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, transparent 55%, rgba(244,234,217,0.55) 78%, #ebdfc9 100%)",
          }}
        />

        {/* top fade — softens the join with the lightest part of the gradient */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, #fffdf8 0%, rgba(255,253,248,0.4) 10%, transparent 22%)",
          }}
        />

        {/* whole-image warm tint — nudges the photo's cool whites/blues
            toward the cream palette so it reads as one cohesive scene */}
        <div
          className="absolute inset-0 mix-blend-multiply"
          style={{
            background:
              "linear-gradient(160deg, rgba(253,248,238,0.18) 0%, rgba(244,234,217,0.12) 50%, rgba(235,223,201,0.16) 100%)",
          }}
        />
      </motion.div>

      <div className="relative z-[1] mx-auto max-w-7xl px-6  pt-16 pb-0  ">
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="flex max-w-xl flex-col items-start text-left"
        >
          <motion.div variants={item}>
            <Eyebrow className="text-[11px]">ROOFING SEO SPECIALISTS</Eyebrow>
          </motion.div>

          <motion.h1
            variants={item}
            className="font-heading text-5xl font-black leading-[1.08] tracking-tight"
          >
            <motion.span variants={item}>Roofing SEO</motion.span>
            <br />
            <motion.span variants={item}>Company for</motion.span>
            <br />
            <motion.span variants={item} style={{ color: "#eb5e28" }}>
              Growth-Focused
            </motion.span>
            <br />
            <motion.span variants={item} style={{ color: "#eb5e28" }}>
              Roofing Businesses
            </motion.span>
          </motion.h1>
          <motion.div variants={item}>
            <motion.p
              // variants={item}
              className="sub-heading mt-6 max-w-sm text-sm font-light font-semibold leading-tight text-[#403d39]"
            >
              Get found in Google Search, Google Maps, and AI Search before
              your competitors—and turn more local searches into qualified
              roofing leads.
            </motion.p>

            <motion.span
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ duration: 0.5, delay: 1.5, ease: [0.22, 0.55, 0.5, 1] }}
              className="mt-6 block h-[3px] w-20 origin-center bg-[#eb5e28]"
            />

            <motion.p className="mt-6 max-w-sm text-sm font-light leading-relaxed text-[#403d39]`">
              Our roofing SEO services combine technical SEO, Google Business
              Profile optimization, reputation management, and
              conversion-focused websites to help roofing companies generate
              more qualified leads and grow their business.
            </motion.p>
          </motion.div>
          <motion.div variants={item} className="mt-8 flex flex-wrap gap-4">
            <PrimaryButton as="a" href="/book-a-call">
              Book a Call <ArrowRight className="h-4 w-4" />
            </PrimaryButton>
            <SecondaryButton as="a" href="/free-audit">
              Get a Free Audit
            </SecondaryButton>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}