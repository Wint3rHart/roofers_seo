
"use client"
import {
  ArrowRight,
  Star,
  MapPin,
  Globe,
  Sparkles,
} from "lucide-react";
import { motion } from "framer-motion"; // Added Framer Motion
import { Eyebrow } from "../ui/ui_components";
import Link from "next/link";

const SERVICES = [
  {
    icon: Star,
    title: "Reputation Management",
    href: "/services/reputation-management",
    copy:
      "Get more 5-star Google reviews on autopilot, route negative feedback privately before it goes public, and turn happy customers into your strongest ranking signal — because review count and review velocity are two of the biggest factors homeowners and Google both use to decide who’s trustworthy.",
  },
  {
    icon: MapPin,
    title: "Local SEO",
    href: "/services/local-seo",
    copy:
      "Rank higher in the Google Map Pack and local search results for “roofer near me” and storm-related searches in your service area, with Google Business Profile optimization, citation building, and local content built around the neighborhoods you actually work in.",
  },
  {
    icon: Globe,
    title: "Web Design",
    href: "/services/web-design",
    copy:
      "A fast, mobile-friendly website designed to convert visitors into calls — built with the on-page SEO structure (titles, headers, schema, internal linking) that search engines need to rank roofing pages, not just a pretty template.",
  },
  {
    icon: Sparkles,
    title: "AI Search Visibility",
    href: "/services/ai-search-visibility",
    copy:
      "Show up when homeowners ask AI tools like ChatGPT and Google AI Overviews “who’s the best roofer near me” — by structuring your reviews, content, and business data in the format these tools actually pull answers from.",
  },
];

// Animation configurations
const fadeUpVariant = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
  }
};

const cardGridVariant = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.15 } // Delays each card entry sequentially
  }
};

const cardItemVariant = {
  hidden: { opacity: 0, y: 40 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.5, ease: [0.25, 1, 0.5, 1] }
  }
};

export const Services = () => {
  return (
    <section className="border-b border-[#ccc5b9]/60 bg-[#fffcf7] text-[#252422]">
      <div className="mx-auto max-w-7xl px-6 py-20 text-center lg:px-10">
        
        {/* Header Elements with Scroll Intro */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: false, margin: "-80px" }}
          variants={fadeUpVariant}
        >
          <Eyebrow>OUR SERVICES</Eyebrow>
        </motion.div>

        <motion.h2 
          className="mx-auto max-w-2xl font-heading text-3xl font-black italic leading-tight tracking-tight sm:text-4xl mt-2"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: false, margin: "-100px" }}
          variants={fadeUpVariant}
          transition={{ delay: 0.1 }}
        >
          Built to Get Roofers Found, Trusted, and Hired
        </motion.h2>

        {/* Expanding Orange Accent Line */}
        <motion.div 
          className="h-1 bg-[#eb5e28] mt-4 rounded-full mx-auto"
          initial={{ width: 0, opacity: 0 }}
          whileInView={{ width: "80px", opacity: 1 }}
          viewport={{ once: false }}
          transition={{ delay: 0.3, duration: 0.6, ease: "easeOut" }}
        />

        <motion.p 
          className="sub-heading mx-auto mt-5 max-w-xl text-sm font-light text-[#403d39]/80"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: false, margin: "-100px" }}
          variants={fadeUpVariant}
          transition={{ delay: 0.2 }}
        >
          Four services, one goal — more homeowners choosing your roofing
          company over the competition.
        </motion.p>

        {/* Interactive Cards Grid */}
        <motion.div 
          className="mt-12 grid gap-6 text-left sm:grid-cols-2"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-50px" }}
          variants={cardGridVariant}
        >
          {SERVICES.map(({ icon: Icon, title, copy, href }) => (
            <motion.div
              key={title}
              variants={cardItemVariant}
              whileHover={{ 
                y: -6, 
                borderColor: "rgba(235, 94, 40, 0.4)", // Changes border to match brand accent color
                boxShadow: "0 20px 25px -5px rgb(0 0 0 / 0.05), 0 8px 10px -6px rgb(0 0 0 / 0.05)"
              }}
              className="group text-center flex flex-col rounded-xl border border-[#ccc5b9]/70 bg-white/40 p-7 transition-colors duration-300 hover:bg-white"
            >
              {/* Icon wrapper with a micro scale animation on card hover */}
              <motion.div
                className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg transition-transform duration-300 group-hover:scale-110"
                style={{ background: "#eb5e28" }}
              >
                <Icon className="h-5 w-5 text-[#fffcf2]" />
              </motion.div>
              
              <h3 className="font-heading text-lg font-bold">{title}</h3>
              <p className="mt-2 flex-1 text-sm leading-relaxed text-[#403d39]/85">
                {copy}
              </p>
              
             <Link
  href={href}
  className="mt-4 inline-flex self-end items-center gap-1 text-sm font-bold"
  style={{ color: "#eb5e28" }}
>
  Learn More 
  <ArrowRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-1.5" />
</Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};