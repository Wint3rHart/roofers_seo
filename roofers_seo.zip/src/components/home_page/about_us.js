"use client"
import React from "react";
import { Star, MapPin, Sparkles } from "lucide-react";
import { motion } from "framer-motion"; // Added Framer Motion
import { Eyebrow, PrimaryButton } from "../ui/ui_components";

const ABOUT_PARAGRAPHS = [
  "Roofing-only strategy means no time wasted explaining storm season or insurance claims — so your plan is right from month one, not month four.",
  "Reviews come before rankings, because homeowners check stars before they check a website — so fixing your reputation first makes every visitor after that convert better.",
  "Reporting tracks calls and ranked keywords, not raw traffic — so the numbers you see are the numbers that actually turn into booked jobs.",
];

const ABOUT_STATS = [
  { icon: Star, label: "Roofing-Only Focus" },
  { icon: MapPin, label: "Month-to-Month Agreements" },
  { icon: Sparkles, label: "Reviews-First Approach" },
];

// Reusable animation variants
const fadeInVariant = {
  hidden: { opacity: 0, y: 30 },
  visible: { 
    opacity: 1, 
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
  }
};

const AboutUs = () => {
  return (
    <section className="border-b border-[#ccc5b9]/60 bg-[#fffcf7] text-[#252422]">
      < motion.div  
             className="mx-auto grid max-w-7xl gap-12 px-6 py-20 lg:grid-cols-5 lg:px-10">
        
        {/* Left Column (Content): Fully centered across all screens */}
        <div className="lg:col-span-3 flex flex-col items-center text-center">
          
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px",amount:".5" }}
            variants={fadeInVariant}
          >
            <Eyebrow>WHO WE ARE</Eyebrow>
          </motion.div>

          <motion.h2 
            className="font-heading max-w-xl text-3xl font-black italic tracking-tight sm:text-4xl mt-2"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-100px" }}
            variants={fadeInVariant}
          >
            SEO and Reputation Management Built for Roofing Businesses
          </motion.h2>

          {/* Animating Orange Bar that expands outward from center */}
          <motion.div 
            className="h-1 bg-[#eb5e28] mt-4 rounded-full"
            initial={{ width: 0, opacity: 0 }}
            whileInView={{ width: "80px", opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2, duration: 0.6, ease: "easeOut" }}
          />

          {/* Paragraphs container */}
          <div className="mt-6 space-y-4 flex flex-col items-center">
            {ABOUT_PARAGRAPHS.map((p, i) => (
              <motion.p
                key={p}
                className="sub-heading max-w-xl text-sm font-light leading-relaxed text-[#403d39]/90"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-50px" }}
                variants={fadeInVariant}
                transition={{ delay: i * 0.1 }}
              >
                {p}
              </motion.p>
            ))}
          </div>

          {/* Centered Stats Icons */}
          <motion.div 
            className="mt-8 flex flex-wrap justify-center gap-x-8 gap-y-4"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={{
              visible: { transition: { staggerChildren: 0.1 } }
            }}
          >
            {ABOUT_STATS.map(({ icon: Icon, label }) => (
              <motion.div 
                key={label} 
                className="flex items-center gap-2"
                variants={fadeInVariant}
              >
                <Icon className="h-5 w-5" style={{ color: "#eb5e28" }} />
                <span className="text-sm font-bold">{label}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* Right Column (Form Panel) */}
        <motion.div 
          className="lg:col-span-2"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <div className="rounded-2xl bg-[#252422] p-8 text-[#fffcf2] shadow-xl">
            <h3 className="font-heading text-xl font-bold italic">
              Let&apos;s Talk About Your Rankings
            </h3>
            <form className="mt-6 space-y-4" action="/thank-you" method="post">
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="text"
                  name="name"
                  required
                  placeholder="Name"
                  className="col-span-1 rounded-md border border-[#403d39] bg-[#fffcf2]/5 px-4 py-3 text-sm placeholder:text-[#ccc5b9] focus:border-[#eb5e28] focus:outline-none"
                />
                <input
                  type="text"
                  name="business_name"
                  required
                  placeholder="Business Name"
                  className="col-span-1 rounded-md border border-[#403d39] bg-[#fffcf2]/5 px-4 py-3 text-sm placeholder:text-[#ccc5b9] focus:border-[#eb5e28] focus:outline-none"
                />
              </div>
              <input
                type="text"
                name="website_url"
                placeholder="Website URL"
                className="w-full rounded-md border border-[#403d39] bg-[#fffcf2]/5 px-4 py-3 text-sm placeholder:text-[#ccc5b9] focus:border-[#eb5e28] focus:outline-none"
              />
              <input
                type="text"
                name="city"
                required
                placeholder="City"
                className="w-full rounded-md border border-[#403d39] bg-[#fffcf2]/5 px-4 py-3 text-sm placeholder:text-[#ccc5b9] focus:border-[#eb5e28] focus:outline-none"
              />
              <input
                type="text"
                name="email_or_phone"
                required
                placeholder="Email or Phone"
                className="w-full rounded-md border border-[#403d39] bg-[#fffcf2]/5 px-4 py-3 text-sm placeholder:text-[#ccc5b9] focus:border-[#eb5e28] focus:outline-none"
              />
              <PrimaryButton as="button" type="submit" className="w-full">
                Get My Free Audit
              </PrimaryButton>
            </form>
          </div>
        </motion.div>

      </motion.div>
    </section>
  );
};

export default AboutUs;